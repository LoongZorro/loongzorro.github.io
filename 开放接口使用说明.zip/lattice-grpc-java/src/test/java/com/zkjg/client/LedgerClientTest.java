package com.zkjg.client;

import com.zkjg.generated.ledger.v1.BatchWriteLedgerResponse;
import com.zkjg.generated.ledger.v1.CreateBusinessResponse;
import com.zkjg.generated.ledger.v1.CreateProtocolResponse;
import com.zkjg.generated.ledger.v1.WriteLedgerData;
import com.zkjg.generated.ledger.v1.WriteLedgerResponse;
import com.zkjg.utils.BaseResult;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

class LedgerClientTest {

    // 返回示例
    // {
    //   "uri": "42949672961",
    //   "hash": "0x75170183b7df4b52775f71ab69af673e01c3d5715682ed33af062835e048018a"
    // }
    @Test
    void createProtocol() {
        BaseResult<CreateProtocolResponse> result = LedgerClient.createProtocol(
                10,
                "syntax = \"proto3\";\n\nmessage Student {\n\tstring id = 1;\n\tstring name = 2;\n}"
        );
        Client.handleResult(result);
    }

    // 返回示例
    // {
    //   "address": "zltc_YBomBNykwMqxm719giBL3VtYV4ABT9a8D",
    //   "hash": "0x505ce44df989983715c389f4859c96cc5ea55f0ee19f7f86a28dca9d2c81c697"
    // }
    @Test
    void createBusiness() {
        BaseResult<CreateBusinessResponse> result = LedgerClient.createBusiness();
        Client.handleResult(result);
    }

    // 返回示例
    // {
    //   "hash": "0xa41e6aed5dc28cb0968175fedc127b00a91a661a4e0e74dca678634bda031532",
    //   "dataId": "0xoUAZPjMxQUbPU0V1Hj5IuzVIGMlo4v1TI8M9DCymvGJkSigidaqoZnX9CMksn3hr"
    // }
    @Test
    void write() {
        BaseResult<WriteLedgerResponse> result = LedgerClient.write(
                42949672961L,
                0,
                "zltc_YBomBNykwMqxm719giBL3VtYV4ABT9a8D",
                "{\"id\":\"2\",\"name\":\"Captain America\"}"
        );
        Client.handleResult(result);
    }

    // 返回示例
    // {
    //   "hash": "0xc3d21dfbff20ada4041e9041136d565fd6980a2feaece2cad44ed76beac3fa3d"
    // }
    @Test
    void batchWrite() {
        BaseResult<BatchWriteLedgerResponse> result = LedgerClient.batchWrite(
                42949672961L,
                "zltc_YBomBNykwMqxm719giBL3VtYV4ABT9a8D",
                Arrays.asList(
                        WriteLedgerData.newBuilder()
                                .setDataId("1")
                                .setData("{\"id\":\"1\",\"name\":\"Jack\"}")
                                .setVersion(0)
                                .build(),
                        WriteLedgerData.newBuilder()
                                .setDataId("2")
                                .setData("{\"id\":\"2\",\"name\":\"Rose\"}")
                                .setVersion(0)
                                .build()
                )
        );
        Client.handleResult(result);
    }
}
