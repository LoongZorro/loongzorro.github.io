package com.zkjg.utils;

import org.bouncycastle.util.encoders.Hex;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;

class SM4Test {

    @Test
    void encryptUseECB() {
        String data = "Hello World";
        String key = "0123456789012345";
        byte[] cipher = SM4.ECB.encrypt(data.getBytes(StandardCharsets.UTF_8), key.getBytes(StandardCharsets.UTF_8));
        String actual = Hex.toHexString(cipher);
        String excepted = "cfda576805c2f27b37a202eeb4a21ddc";
        Assertions.assertEquals(excepted, actual);
    }
}
