package com.zkjg.utils;

import org.bouncycastle.util.encoders.Hex;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;

class SM3Test {

    @Test
    void hash() {
        String data = "Hello World";
        byte[] hash = SM3.hash(data.getBytes(StandardCharsets.UTF_8));
        String actual = Hex.toHexString(hash);
        String expected = "77015816143ee627f4fa410b6dad2bdb9fcbdf1e061a452a686b8711a484c5d7";
        Assertions.assertEquals(expected, actual);
    }
}
