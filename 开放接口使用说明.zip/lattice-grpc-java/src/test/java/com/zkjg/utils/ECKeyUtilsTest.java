package com.zkjg.utils;

import org.junit.jupiter.api.Test;

import java.security.interfaces.ECKey;

class ECKeyUtilsTest {
    @Test
    void fromHexPrivateKey() {
        String privateKey = "15cd122933a554fdbd6dd0ed38b9a148733b0b57b1ccc49467f1d14878174630";
        ECKey ecPrivateKey = ECKeyUtils.fromHexPrivateKey(privateKey);
        System.out.println(ecPrivateKey);
    }

    @Test
    void fromHexPublicKey() {
        String publicKey = "0448e89538d7f403226b1c74e30e3f4c9793f6b3894a28665725177df2c1d19af161c40845191690b01d039f79bb15aef205faff7a8b47ecf97aa0902f79553bd5";
        ECKey ecPublicKey = ECKeyUtils.fromUncompressedPublicKey(publicKey);
        System.out.println(ecPublicKey);
    }
}
