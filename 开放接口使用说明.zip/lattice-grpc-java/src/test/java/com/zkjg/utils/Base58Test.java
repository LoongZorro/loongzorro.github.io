package com.zkjg.utils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;

class Base58Test {
    @Test
    void encode() {
        String data = "Hello World";
        String actual = Base58.encode(data.getBytes(StandardCharsets.UTF_8));
        String expected = "JxF12TrwUP45BMd";
        Assertions.assertEquals(expected, actual);
    }
}
