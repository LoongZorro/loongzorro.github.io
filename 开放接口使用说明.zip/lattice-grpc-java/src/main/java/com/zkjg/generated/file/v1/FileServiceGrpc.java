package com.zkjg.generated.file.v1;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.66.0)",
    comments = "Source: file/v1/file.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class FileServiceGrpc {

  private FileServiceGrpc() {}

  public static final java.lang.String SERVICE_NAME = "file.v1.FileService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.file.v1.UploadChunkToChainRequest,
      com.zkjg.generated.file.v1.UploadChunkToChainResponse> getUploadChunkToChainMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UploadChunkToChain",
      requestType = com.zkjg.generated.file.v1.UploadChunkToChainRequest.class,
      responseType = com.zkjg.generated.file.v1.UploadChunkToChainResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.CLIENT_STREAMING)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.file.v1.UploadChunkToChainRequest,
      com.zkjg.generated.file.v1.UploadChunkToChainResponse> getUploadChunkToChainMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.file.v1.UploadChunkToChainRequest, com.zkjg.generated.file.v1.UploadChunkToChainResponse> getUploadChunkToChainMethod;
    if ((getUploadChunkToChainMethod = FileServiceGrpc.getUploadChunkToChainMethod) == null) {
      synchronized (FileServiceGrpc.class) {
        if ((getUploadChunkToChainMethod = FileServiceGrpc.getUploadChunkToChainMethod) == null) {
          FileServiceGrpc.getUploadChunkToChainMethod = getUploadChunkToChainMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.file.v1.UploadChunkToChainRequest, com.zkjg.generated.file.v1.UploadChunkToChainResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.CLIENT_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UploadChunkToChain"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.file.v1.UploadChunkToChainRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.file.v1.UploadChunkToChainResponse.getDefaultInstance()))
              .setSchemaDescriptor(new FileServiceMethodDescriptorSupplier("UploadChunkToChain"))
              .build();
        }
      }
    }
    return getUploadChunkToChainMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.file.v1.DownloadChunkFromChainRequest,
      com.zkjg.generated.file.v1.DownloadChunkFromChainResponse> getDownloadChunkFromChainMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DownloadChunkFromChain",
      requestType = com.zkjg.generated.file.v1.DownloadChunkFromChainRequest.class,
      responseType = com.zkjg.generated.file.v1.DownloadChunkFromChainResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.file.v1.DownloadChunkFromChainRequest,
      com.zkjg.generated.file.v1.DownloadChunkFromChainResponse> getDownloadChunkFromChainMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.file.v1.DownloadChunkFromChainRequest, com.zkjg.generated.file.v1.DownloadChunkFromChainResponse> getDownloadChunkFromChainMethod;
    if ((getDownloadChunkFromChainMethod = FileServiceGrpc.getDownloadChunkFromChainMethod) == null) {
      synchronized (FileServiceGrpc.class) {
        if ((getDownloadChunkFromChainMethod = FileServiceGrpc.getDownloadChunkFromChainMethod) == null) {
          FileServiceGrpc.getDownloadChunkFromChainMethod = getDownloadChunkFromChainMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.file.v1.DownloadChunkFromChainRequest, com.zkjg.generated.file.v1.DownloadChunkFromChainResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DownloadChunkFromChain"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.file.v1.DownloadChunkFromChainRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.file.v1.DownloadChunkFromChainResponse.getDefaultInstance()))
              .setSchemaDescriptor(new FileServiceMethodDescriptorSupplier("DownloadChunkFromChain"))
              .build();
        }
      }
    }
    return getDownloadChunkFromChainMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static FileServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<FileServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<FileServiceStub>() {
        @java.lang.Override
        public FileServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new FileServiceStub(channel, callOptions);
        }
      };
    return FileServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static FileServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<FileServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<FileServiceBlockingStub>() {
        @java.lang.Override
        public FileServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new FileServiceBlockingStub(channel, callOptions);
        }
      };
    return FileServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static FileServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<FileServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<FileServiceFutureStub>() {
        @java.lang.Override
        public FileServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new FileServiceFutureStub(channel, callOptions);
        }
      };
    return FileServiceFutureStub.newStub(factory, channel);
  }

  /**
   */
  public interface AsyncService {

    /**
     * <pre>
     * 上传文件到链上
     * </pre>
     */
    default io.grpc.stub.StreamObserver<com.zkjg.generated.file.v1.UploadChunkToChainRequest> uploadChunkToChain(
        io.grpc.stub.StreamObserver<com.zkjg.generated.file.v1.UploadChunkToChainResponse> responseObserver) {
      return io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall(getUploadChunkToChainMethod(), responseObserver);
    }

    /**
     * <pre>
     * 从链上下载文件
     * </pre>
     */
    default void downloadChunkFromChain(com.zkjg.generated.file.v1.DownloadChunkFromChainRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.file.v1.DownloadChunkFromChainResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDownloadChunkFromChainMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service FileService.
   */
  public static abstract class FileServiceImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return FileServiceGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service FileService.
   */
  public static final class FileServiceStub
      extends io.grpc.stub.AbstractAsyncStub<FileServiceStub> {
    private FileServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected FileServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new FileServiceStub(channel, callOptions);
    }

    /**
     * <pre>
     * 上传文件到链上
     * </pre>
     */
    public io.grpc.stub.StreamObserver<com.zkjg.generated.file.v1.UploadChunkToChainRequest> uploadChunkToChain(
        io.grpc.stub.StreamObserver<com.zkjg.generated.file.v1.UploadChunkToChainResponse> responseObserver) {
      return io.grpc.stub.ClientCalls.asyncClientStreamingCall(
          getChannel().newCall(getUploadChunkToChainMethod(), getCallOptions()), responseObserver);
    }

    /**
     * <pre>
     * 从链上下载文件
     * </pre>
     */
    public void downloadChunkFromChain(com.zkjg.generated.file.v1.DownloadChunkFromChainRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.file.v1.DownloadChunkFromChainResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getDownloadChunkFromChainMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service FileService.
   */
  public static final class FileServiceBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<FileServiceBlockingStub> {
    private FileServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected FileServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new FileServiceBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * 从链上下载文件
     * </pre>
     */
    public java.util.Iterator<com.zkjg.generated.file.v1.DownloadChunkFromChainResponse> downloadChunkFromChain(
        com.zkjg.generated.file.v1.DownloadChunkFromChainRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getDownloadChunkFromChainMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service FileService.
   */
  public static final class FileServiceFutureStub
      extends io.grpc.stub.AbstractFutureStub<FileServiceFutureStub> {
    private FileServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected FileServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new FileServiceFutureStub(channel, callOptions);
    }
  }

  private static final int METHODID_DOWNLOAD_CHUNK_FROM_CHAIN = 0;
  private static final int METHODID_UPLOAD_CHUNK_TO_CHAIN = 1;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_DOWNLOAD_CHUNK_FROM_CHAIN:
          serviceImpl.downloadChunkFromChain((com.zkjg.generated.file.v1.DownloadChunkFromChainRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.file.v1.DownloadChunkFromChainResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_UPLOAD_CHUNK_TO_CHAIN:
          return (io.grpc.stub.StreamObserver<Req>) serviceImpl.uploadChunkToChain(
              (io.grpc.stub.StreamObserver<com.zkjg.generated.file.v1.UploadChunkToChainResponse>) responseObserver);
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getUploadChunkToChainMethod(),
          io.grpc.stub.ServerCalls.asyncClientStreamingCall(
            new MethodHandlers<
              com.zkjg.generated.file.v1.UploadChunkToChainRequest,
              com.zkjg.generated.file.v1.UploadChunkToChainResponse>(
                service, METHODID_UPLOAD_CHUNK_TO_CHAIN)))
        .addMethod(
          getDownloadChunkFromChainMethod(),
          io.grpc.stub.ServerCalls.asyncServerStreamingCall(
            new MethodHandlers<
              com.zkjg.generated.file.v1.DownloadChunkFromChainRequest,
              com.zkjg.generated.file.v1.DownloadChunkFromChainResponse>(
                service, METHODID_DOWNLOAD_CHUNK_FROM_CHAIN)))
        .build();
  }

  private static abstract class FileServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    FileServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.zkjg.generated.file.v1.FileProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("FileService");
    }
  }

  private static final class FileServiceFileDescriptorSupplier
      extends FileServiceBaseDescriptorSupplier {
    FileServiceFileDescriptorSupplier() {}
  }

  private static final class FileServiceMethodDescriptorSupplier
      extends FileServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    FileServiceMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (FileServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new FileServiceFileDescriptorSupplier())
              .addMethod(getUploadChunkToChainMethod())
              .addMethod(getDownloadChunkFromChainMethod())
              .build();
        }
      }
    }
    return result;
  }
}
