package com.zkjg.generated.ledger.v1;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.66.0)",
    comments = "Source: ledger/v1/ledger.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class LedgerServiceGrpc {

  private LedgerServiceGrpc() {}

  public static final java.lang.String SERVICE_NAME = "ledger.v1.LedgerService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.CreateProtocolRequest,
      com.zkjg.generated.ledger.v1.CreateProtocolResponse> getCreateProtocolMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateProtocol",
      requestType = com.zkjg.generated.ledger.v1.CreateProtocolRequest.class,
      responseType = com.zkjg.generated.ledger.v1.CreateProtocolResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.CreateProtocolRequest,
      com.zkjg.generated.ledger.v1.CreateProtocolResponse> getCreateProtocolMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.CreateProtocolRequest, com.zkjg.generated.ledger.v1.CreateProtocolResponse> getCreateProtocolMethod;
    if ((getCreateProtocolMethod = LedgerServiceGrpc.getCreateProtocolMethod) == null) {
      synchronized (LedgerServiceGrpc.class) {
        if ((getCreateProtocolMethod = LedgerServiceGrpc.getCreateProtocolMethod) == null) {
          LedgerServiceGrpc.getCreateProtocolMethod = getCreateProtocolMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.ledger.v1.CreateProtocolRequest, com.zkjg.generated.ledger.v1.CreateProtocolResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateProtocol"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.CreateProtocolRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.CreateProtocolResponse.getDefaultInstance()))
              .setSchemaDescriptor(new LedgerServiceMethodDescriptorSupplier("CreateProtocol"))
              .build();
        }
      }
    }
    return getCreateProtocolMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.BatchCreateProtocolRequest,
      com.zkjg.generated.ledger.v1.BatchCreateProtocolResponse> getBatchCreateProtocolMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "BatchCreateProtocol",
      requestType = com.zkjg.generated.ledger.v1.BatchCreateProtocolRequest.class,
      responseType = com.zkjg.generated.ledger.v1.BatchCreateProtocolResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.BatchCreateProtocolRequest,
      com.zkjg.generated.ledger.v1.BatchCreateProtocolResponse> getBatchCreateProtocolMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.BatchCreateProtocolRequest, com.zkjg.generated.ledger.v1.BatchCreateProtocolResponse> getBatchCreateProtocolMethod;
    if ((getBatchCreateProtocolMethod = LedgerServiceGrpc.getBatchCreateProtocolMethod) == null) {
      synchronized (LedgerServiceGrpc.class) {
        if ((getBatchCreateProtocolMethod = LedgerServiceGrpc.getBatchCreateProtocolMethod) == null) {
          LedgerServiceGrpc.getBatchCreateProtocolMethod = getBatchCreateProtocolMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.ledger.v1.BatchCreateProtocolRequest, com.zkjg.generated.ledger.v1.BatchCreateProtocolResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "BatchCreateProtocol"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.BatchCreateProtocolRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.BatchCreateProtocolResponse.getDefaultInstance()))
              .setSchemaDescriptor(new LedgerServiceMethodDescriptorSupplier("BatchCreateProtocol"))
              .build();
        }
      }
    }
    return getBatchCreateProtocolMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.UpdateProtocolRequest,
      com.zkjg.generated.ledger.v1.UpdateProtocolResponse> getUpdateProtocolMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateProtocol",
      requestType = com.zkjg.generated.ledger.v1.UpdateProtocolRequest.class,
      responseType = com.zkjg.generated.ledger.v1.UpdateProtocolResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.UpdateProtocolRequest,
      com.zkjg.generated.ledger.v1.UpdateProtocolResponse> getUpdateProtocolMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.UpdateProtocolRequest, com.zkjg.generated.ledger.v1.UpdateProtocolResponse> getUpdateProtocolMethod;
    if ((getUpdateProtocolMethod = LedgerServiceGrpc.getUpdateProtocolMethod) == null) {
      synchronized (LedgerServiceGrpc.class) {
        if ((getUpdateProtocolMethod = LedgerServiceGrpc.getUpdateProtocolMethod) == null) {
          LedgerServiceGrpc.getUpdateProtocolMethod = getUpdateProtocolMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.ledger.v1.UpdateProtocolRequest, com.zkjg.generated.ledger.v1.UpdateProtocolResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateProtocol"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.UpdateProtocolRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.UpdateProtocolResponse.getDefaultInstance()))
              .setSchemaDescriptor(new LedgerServiceMethodDescriptorSupplier("UpdateProtocol"))
              .build();
        }
      }
    }
    return getUpdateProtocolMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.BatchUpdateProtocolRequest,
      com.zkjg.generated.ledger.v1.BatchUpdateProtocolResponse> getBatchUpdateProtocolMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "BatchUpdateProtocol",
      requestType = com.zkjg.generated.ledger.v1.BatchUpdateProtocolRequest.class,
      responseType = com.zkjg.generated.ledger.v1.BatchUpdateProtocolResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.BatchUpdateProtocolRequest,
      com.zkjg.generated.ledger.v1.BatchUpdateProtocolResponse> getBatchUpdateProtocolMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.BatchUpdateProtocolRequest, com.zkjg.generated.ledger.v1.BatchUpdateProtocolResponse> getBatchUpdateProtocolMethod;
    if ((getBatchUpdateProtocolMethod = LedgerServiceGrpc.getBatchUpdateProtocolMethod) == null) {
      synchronized (LedgerServiceGrpc.class) {
        if ((getBatchUpdateProtocolMethod = LedgerServiceGrpc.getBatchUpdateProtocolMethod) == null) {
          LedgerServiceGrpc.getBatchUpdateProtocolMethod = getBatchUpdateProtocolMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.ledger.v1.BatchUpdateProtocolRequest, com.zkjg.generated.ledger.v1.BatchUpdateProtocolResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "BatchUpdateProtocol"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.BatchUpdateProtocolRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.BatchUpdateProtocolResponse.getDefaultInstance()))
              .setSchemaDescriptor(new LedgerServiceMethodDescriptorSupplier("BatchUpdateProtocol"))
              .build();
        }
      }
    }
    return getBatchUpdateProtocolMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.ReadProtocolRequest,
      com.zkjg.generated.ledger.v1.ReadProtocolResponse> getReadProtocolMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ReadProtocol",
      requestType = com.zkjg.generated.ledger.v1.ReadProtocolRequest.class,
      responseType = com.zkjg.generated.ledger.v1.ReadProtocolResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.ReadProtocolRequest,
      com.zkjg.generated.ledger.v1.ReadProtocolResponse> getReadProtocolMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.ReadProtocolRequest, com.zkjg.generated.ledger.v1.ReadProtocolResponse> getReadProtocolMethod;
    if ((getReadProtocolMethod = LedgerServiceGrpc.getReadProtocolMethod) == null) {
      synchronized (LedgerServiceGrpc.class) {
        if ((getReadProtocolMethod = LedgerServiceGrpc.getReadProtocolMethod) == null) {
          LedgerServiceGrpc.getReadProtocolMethod = getReadProtocolMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.ledger.v1.ReadProtocolRequest, com.zkjg.generated.ledger.v1.ReadProtocolResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ReadProtocol"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.ReadProtocolRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.ReadProtocolResponse.getDefaultInstance()))
              .setSchemaDescriptor(new LedgerServiceMethodDescriptorSupplier("ReadProtocol"))
              .build();
        }
      }
    }
    return getReadProtocolMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.CreateBusinessRequest,
      com.zkjg.generated.ledger.v1.CreateBusinessResponse> getCreateBusinessMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateBusiness",
      requestType = com.zkjg.generated.ledger.v1.CreateBusinessRequest.class,
      responseType = com.zkjg.generated.ledger.v1.CreateBusinessResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.CreateBusinessRequest,
      com.zkjg.generated.ledger.v1.CreateBusinessResponse> getCreateBusinessMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.CreateBusinessRequest, com.zkjg.generated.ledger.v1.CreateBusinessResponse> getCreateBusinessMethod;
    if ((getCreateBusinessMethod = LedgerServiceGrpc.getCreateBusinessMethod) == null) {
      synchronized (LedgerServiceGrpc.class) {
        if ((getCreateBusinessMethod = LedgerServiceGrpc.getCreateBusinessMethod) == null) {
          LedgerServiceGrpc.getCreateBusinessMethod = getCreateBusinessMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.ledger.v1.CreateBusinessRequest, com.zkjg.generated.ledger.v1.CreateBusinessResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateBusiness"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.CreateBusinessRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.CreateBusinessResponse.getDefaultInstance()))
              .setSchemaDescriptor(new LedgerServiceMethodDescriptorSupplier("CreateBusiness"))
              .build();
        }
      }
    }
    return getCreateBusinessMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.ExistsBusinessRequest,
      com.zkjg.generated.ledger.v1.ExistsBusinessResponse> getExistsBusinessMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ExistsBusiness",
      requestType = com.zkjg.generated.ledger.v1.ExistsBusinessRequest.class,
      responseType = com.zkjg.generated.ledger.v1.ExistsBusinessResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.ExistsBusinessRequest,
      com.zkjg.generated.ledger.v1.ExistsBusinessResponse> getExistsBusinessMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.ExistsBusinessRequest, com.zkjg.generated.ledger.v1.ExistsBusinessResponse> getExistsBusinessMethod;
    if ((getExistsBusinessMethod = LedgerServiceGrpc.getExistsBusinessMethod) == null) {
      synchronized (LedgerServiceGrpc.class) {
        if ((getExistsBusinessMethod = LedgerServiceGrpc.getExistsBusinessMethod) == null) {
          LedgerServiceGrpc.getExistsBusinessMethod = getExistsBusinessMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.ledger.v1.ExistsBusinessRequest, com.zkjg.generated.ledger.v1.ExistsBusinessResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ExistsBusiness"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.ExistsBusinessRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.ExistsBusinessResponse.getDefaultInstance()))
              .setSchemaDescriptor(new LedgerServiceMethodDescriptorSupplier("ExistsBusiness"))
              .build();
        }
      }
    }
    return getExistsBusinessMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.WriteLedgerRequest,
      com.zkjg.generated.ledger.v1.WriteLedgerResponse> getWriteMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Write",
      requestType = com.zkjg.generated.ledger.v1.WriteLedgerRequest.class,
      responseType = com.zkjg.generated.ledger.v1.WriteLedgerResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.WriteLedgerRequest,
      com.zkjg.generated.ledger.v1.WriteLedgerResponse> getWriteMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.WriteLedgerRequest, com.zkjg.generated.ledger.v1.WriteLedgerResponse> getWriteMethod;
    if ((getWriteMethod = LedgerServiceGrpc.getWriteMethod) == null) {
      synchronized (LedgerServiceGrpc.class) {
        if ((getWriteMethod = LedgerServiceGrpc.getWriteMethod) == null) {
          LedgerServiceGrpc.getWriteMethod = getWriteMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.ledger.v1.WriteLedgerRequest, com.zkjg.generated.ledger.v1.WriteLedgerResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Write"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.WriteLedgerRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.WriteLedgerResponse.getDefaultInstance()))
              .setSchemaDescriptor(new LedgerServiceMethodDescriptorSupplier("Write"))
              .build();
        }
      }
    }
    return getWriteMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest,
      com.zkjg.generated.ledger.v1.BatchWriteLedgerResponse> getBatchWriteMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "BatchWrite",
      requestType = com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest.class,
      responseType = com.zkjg.generated.ledger.v1.BatchWriteLedgerResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest,
      com.zkjg.generated.ledger.v1.BatchWriteLedgerResponse> getBatchWriteMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest, com.zkjg.generated.ledger.v1.BatchWriteLedgerResponse> getBatchWriteMethod;
    if ((getBatchWriteMethod = LedgerServiceGrpc.getBatchWriteMethod) == null) {
      synchronized (LedgerServiceGrpc.class) {
        if ((getBatchWriteMethod = LedgerServiceGrpc.getBatchWriteMethod) == null) {
          LedgerServiceGrpc.getBatchWriteMethod = getBatchWriteMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest, com.zkjg.generated.ledger.v1.BatchWriteLedgerResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "BatchWrite"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.BatchWriteLedgerResponse.getDefaultInstance()))
              .setSchemaDescriptor(new LedgerServiceMethodDescriptorSupplier("BatchWrite"))
              .build();
        }
      }
    }
    return getBatchWriteMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest,
      com.zkjg.generated.ledger.v1.SyncBatchWriteLedgerResponse> getSyncBatchWriteMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SyncBatchWrite",
      requestType = com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest.class,
      responseType = com.zkjg.generated.ledger.v1.SyncBatchWriteLedgerResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest,
      com.zkjg.generated.ledger.v1.SyncBatchWriteLedgerResponse> getSyncBatchWriteMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest, com.zkjg.generated.ledger.v1.SyncBatchWriteLedgerResponse> getSyncBatchWriteMethod;
    if ((getSyncBatchWriteMethod = LedgerServiceGrpc.getSyncBatchWriteMethod) == null) {
      synchronized (LedgerServiceGrpc.class) {
        if ((getSyncBatchWriteMethod = LedgerServiceGrpc.getSyncBatchWriteMethod) == null) {
          LedgerServiceGrpc.getSyncBatchWriteMethod = getSyncBatchWriteMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest, com.zkjg.generated.ledger.v1.SyncBatchWriteLedgerResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "SyncBatchWrite"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.SyncBatchWriteLedgerResponse.getDefaultInstance()))
              .setSchemaDescriptor(new LedgerServiceMethodDescriptorSupplier("SyncBatchWrite"))
              .build();
        }
      }
    }
    return getSyncBatchWriteMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.ReadLedgerRequest,
      com.zkjg.generated.ledger.v1.ReadLedgerResponse> getReadMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Read",
      requestType = com.zkjg.generated.ledger.v1.ReadLedgerRequest.class,
      responseType = com.zkjg.generated.ledger.v1.ReadLedgerResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.ReadLedgerRequest,
      com.zkjg.generated.ledger.v1.ReadLedgerResponse> getReadMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.ReadLedgerRequest, com.zkjg.generated.ledger.v1.ReadLedgerResponse> getReadMethod;
    if ((getReadMethod = LedgerServiceGrpc.getReadMethod) == null) {
      synchronized (LedgerServiceGrpc.class) {
        if ((getReadMethod = LedgerServiceGrpc.getReadMethod) == null) {
          LedgerServiceGrpc.getReadMethod = getReadMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.ledger.v1.ReadLedgerRequest, com.zkjg.generated.ledger.v1.ReadLedgerResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Read"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.ReadLedgerRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.ReadLedgerResponse.getDefaultInstance()))
              .setSchemaDescriptor(new LedgerServiceMethodDescriptorSupplier("Read"))
              .build();
        }
      }
    }
    return getReadMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsRequest,
      com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsResponse> getDecodeLedgerTransactionsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DecodeLedgerTransactions",
      requestType = com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsRequest.class,
      responseType = com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsRequest,
      com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsResponse> getDecodeLedgerTransactionsMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsRequest, com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsResponse> getDecodeLedgerTransactionsMethod;
    if ((getDecodeLedgerTransactionsMethod = LedgerServiceGrpc.getDecodeLedgerTransactionsMethod) == null) {
      synchronized (LedgerServiceGrpc.class) {
        if ((getDecodeLedgerTransactionsMethod = LedgerServiceGrpc.getDecodeLedgerTransactionsMethod) == null) {
          LedgerServiceGrpc.getDecodeLedgerTransactionsMethod = getDecodeLedgerTransactionsMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsRequest, com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DecodeLedgerTransactions"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new LedgerServiceMethodDescriptorSupplier("DecodeLedgerTransactions"))
              .build();
        }
      }
    }
    return getDecodeLedgerTransactionsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.DecodeLedgerTransactionRequest,
      com.zkjg.generated.ledger.v1.DecodeLedgerTransactionResponse> getDecodeLedgerTransactionMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DecodeLedgerTransaction",
      requestType = com.zkjg.generated.ledger.v1.DecodeLedgerTransactionRequest.class,
      responseType = com.zkjg.generated.ledger.v1.DecodeLedgerTransactionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.DecodeLedgerTransactionRequest,
      com.zkjg.generated.ledger.v1.DecodeLedgerTransactionResponse> getDecodeLedgerTransactionMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.ledger.v1.DecodeLedgerTransactionRequest, com.zkjg.generated.ledger.v1.DecodeLedgerTransactionResponse> getDecodeLedgerTransactionMethod;
    if ((getDecodeLedgerTransactionMethod = LedgerServiceGrpc.getDecodeLedgerTransactionMethod) == null) {
      synchronized (LedgerServiceGrpc.class) {
        if ((getDecodeLedgerTransactionMethod = LedgerServiceGrpc.getDecodeLedgerTransactionMethod) == null) {
          LedgerServiceGrpc.getDecodeLedgerTransactionMethod = getDecodeLedgerTransactionMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.ledger.v1.DecodeLedgerTransactionRequest, com.zkjg.generated.ledger.v1.DecodeLedgerTransactionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DecodeLedgerTransaction"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.DecodeLedgerTransactionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.ledger.v1.DecodeLedgerTransactionResponse.getDefaultInstance()))
              .setSchemaDescriptor(new LedgerServiceMethodDescriptorSupplier("DecodeLedgerTransaction"))
              .build();
        }
      }
    }
    return getDecodeLedgerTransactionMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static LedgerServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<LedgerServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<LedgerServiceStub>() {
        @java.lang.Override
        public LedgerServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new LedgerServiceStub(channel, callOptions);
        }
      };
    return LedgerServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static LedgerServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<LedgerServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<LedgerServiceBlockingStub>() {
        @java.lang.Override
        public LedgerServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new LedgerServiceBlockingStub(channel, callOptions);
        }
      };
    return LedgerServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static LedgerServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<LedgerServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<LedgerServiceFutureStub>() {
        @java.lang.Override
        public LedgerServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new LedgerServiceFutureStub(channel, callOptions);
        }
      };
    return LedgerServiceFutureStub.newStub(factory, channel);
  }

  /**
   */
  public interface AsyncService {

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 新建存证协议
     * </pre>
     */
    default void createProtocol(com.zkjg.generated.ledger.v1.CreateProtocolRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.CreateProtocolResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateProtocolMethod(), responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 批量新建存证协议
     * </pre>
     */
    default void batchCreateProtocol(com.zkjg.generated.ledger.v1.BatchCreateProtocolRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.BatchCreateProtocolResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getBatchCreateProtocolMethod(), responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 更新存证协议
     * </pre>
     */
    default void updateProtocol(com.zkjg.generated.ledger.v1.UpdateProtocolRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.UpdateProtocolResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateProtocolMethod(), responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 批量更新存证协议
     * </pre>
     */
    default void batchUpdateProtocol(com.zkjg.generated.ledger.v1.BatchUpdateProtocolRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.BatchUpdateProtocolResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getBatchUpdateProtocolMethod(), responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 查询存证协议内容
     * </pre>
     */
    default void readProtocol(com.zkjg.generated.ledger.v1.ReadProtocolRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.ReadProtocolResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getReadProtocolMethod(), responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 创建存证业务合约
     * </pre>
     */
    default void createBusiness(com.zkjg.generated.ledger.v1.CreateBusinessRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.CreateBusinessResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateBusinessMethod(), responseObserver);
    }

    /**
     * <pre>
     * [basic, standard, ak-common-user, ak-baas, ak-data-on-chain]
     * 检查存证业务合约是否存在
     * </pre>
     */
    default void existsBusiness(com.zkjg.generated.ledger.v1.ExistsBusinessRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.ExistsBusinessResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getExistsBusinessMethod(), responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]
     * 存证数据
     * </pre>
     */
    default void write(com.zkjg.generated.ledger.v1.WriteLedgerRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.WriteLedgerResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getWriteMethod(), responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 批量存证数据
     * </pre>
     */
    default void batchWrite(com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.BatchWriteLedgerResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getBatchWriteMethod(), responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 同步批量存证数据
     * </pre>
     */
    default void syncBatchWrite(com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.SyncBatchWriteLedgerResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getSyncBatchWriteMethod(), responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 读取存证数据
     * </pre>
     */
    default void read(com.zkjg.generated.ledger.v1.ReadLedgerRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.ReadLedgerResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getReadMethod(), responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 解码多个存证的交易
     * </pre>
     */
    default void decodeLedgerTransactions(com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDecodeLedgerTransactionsMethod(), responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 解码单个存证的交易
     * </pre>
     */
    default void decodeLedgerTransaction(com.zkjg.generated.ledger.v1.DecodeLedgerTransactionRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.DecodeLedgerTransactionResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDecodeLedgerTransactionMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service LedgerService.
   */
  public static abstract class LedgerServiceImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return LedgerServiceGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service LedgerService.
   */
  public static final class LedgerServiceStub
      extends io.grpc.stub.AbstractAsyncStub<LedgerServiceStub> {
    private LedgerServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected LedgerServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new LedgerServiceStub(channel, callOptions);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 新建存证协议
     * </pre>
     */
    public void createProtocol(com.zkjg.generated.ledger.v1.CreateProtocolRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.CreateProtocolResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateProtocolMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 批量新建存证协议
     * </pre>
     */
    public void batchCreateProtocol(com.zkjg.generated.ledger.v1.BatchCreateProtocolRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.BatchCreateProtocolResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getBatchCreateProtocolMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 更新存证协议
     * </pre>
     */
    public void updateProtocol(com.zkjg.generated.ledger.v1.UpdateProtocolRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.UpdateProtocolResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateProtocolMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 批量更新存证协议
     * </pre>
     */
    public void batchUpdateProtocol(com.zkjg.generated.ledger.v1.BatchUpdateProtocolRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.BatchUpdateProtocolResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getBatchUpdateProtocolMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 查询存证协议内容
     * </pre>
     */
    public void readProtocol(com.zkjg.generated.ledger.v1.ReadProtocolRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.ReadProtocolResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getReadProtocolMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 创建存证业务合约
     * </pre>
     */
    public void createBusiness(com.zkjg.generated.ledger.v1.CreateBusinessRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.CreateBusinessResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateBusinessMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * [basic, standard, ak-common-user, ak-baas, ak-data-on-chain]
     * 检查存证业务合约是否存在
     * </pre>
     */
    public void existsBusiness(com.zkjg.generated.ledger.v1.ExistsBusinessRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.ExistsBusinessResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getExistsBusinessMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]
     * 存证数据
     * </pre>
     */
    public void write(com.zkjg.generated.ledger.v1.WriteLedgerRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.WriteLedgerResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getWriteMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 批量存证数据
     * </pre>
     */
    public void batchWrite(com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.BatchWriteLedgerResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getBatchWriteMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 同步批量存证数据
     * </pre>
     */
    public void syncBatchWrite(com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.SyncBatchWriteLedgerResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getSyncBatchWriteMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 读取存证数据
     * </pre>
     */
    public void read(com.zkjg.generated.ledger.v1.ReadLedgerRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.ReadLedgerResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getReadMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 解码多个存证的交易
     * </pre>
     */
    public void decodeLedgerTransactions(com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDecodeLedgerTransactionsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 解码单个存证的交易
     * </pre>
     */
    public void decodeLedgerTransaction(com.zkjg.generated.ledger.v1.DecodeLedgerTransactionRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.DecodeLedgerTransactionResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDecodeLedgerTransactionMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service LedgerService.
   */
  public static final class LedgerServiceBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<LedgerServiceBlockingStub> {
    private LedgerServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected LedgerServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new LedgerServiceBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 新建存证协议
     * </pre>
     */
    public com.zkjg.generated.ledger.v1.CreateProtocolResponse createProtocol(com.zkjg.generated.ledger.v1.CreateProtocolRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateProtocolMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 批量新建存证协议
     * </pre>
     */
    public com.zkjg.generated.ledger.v1.BatchCreateProtocolResponse batchCreateProtocol(com.zkjg.generated.ledger.v1.BatchCreateProtocolRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getBatchCreateProtocolMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 更新存证协议
     * </pre>
     */
    public com.zkjg.generated.ledger.v1.UpdateProtocolResponse updateProtocol(com.zkjg.generated.ledger.v1.UpdateProtocolRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateProtocolMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 批量更新存证协议
     * </pre>
     */
    public com.zkjg.generated.ledger.v1.BatchUpdateProtocolResponse batchUpdateProtocol(com.zkjg.generated.ledger.v1.BatchUpdateProtocolRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getBatchUpdateProtocolMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 查询存证协议内容
     * </pre>
     */
    public com.zkjg.generated.ledger.v1.ReadProtocolResponse readProtocol(com.zkjg.generated.ledger.v1.ReadProtocolRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getReadProtocolMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 创建存证业务合约
     * </pre>
     */
    public com.zkjg.generated.ledger.v1.CreateBusinessResponse createBusiness(com.zkjg.generated.ledger.v1.CreateBusinessRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateBusinessMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [basic, standard, ak-common-user, ak-baas, ak-data-on-chain]
     * 检查存证业务合约是否存在
     * </pre>
     */
    public com.zkjg.generated.ledger.v1.ExistsBusinessResponse existsBusiness(com.zkjg.generated.ledger.v1.ExistsBusinessRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getExistsBusinessMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]
     * 存证数据
     * </pre>
     */
    public com.zkjg.generated.ledger.v1.WriteLedgerResponse write(com.zkjg.generated.ledger.v1.WriteLedgerRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getWriteMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 批量存证数据
     * </pre>
     */
    public com.zkjg.generated.ledger.v1.BatchWriteLedgerResponse batchWrite(com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getBatchWriteMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 同步批量存证数据
     * </pre>
     */
    public com.zkjg.generated.ledger.v1.SyncBatchWriteLedgerResponse syncBatchWrite(com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getSyncBatchWriteMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 读取存证数据
     * </pre>
     */
    public com.zkjg.generated.ledger.v1.ReadLedgerResponse read(com.zkjg.generated.ledger.v1.ReadLedgerRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getReadMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 解码多个存证的交易
     * </pre>
     */
    public com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsResponse decodeLedgerTransactions(com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDecodeLedgerTransactionsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 解码单个存证的交易
     * </pre>
     */
    public com.zkjg.generated.ledger.v1.DecodeLedgerTransactionResponse decodeLedgerTransaction(com.zkjg.generated.ledger.v1.DecodeLedgerTransactionRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDecodeLedgerTransactionMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service LedgerService.
   */
  public static final class LedgerServiceFutureStub
      extends io.grpc.stub.AbstractFutureStub<LedgerServiceFutureStub> {
    private LedgerServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected LedgerServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new LedgerServiceFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 新建存证协议
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.ledger.v1.CreateProtocolResponse> createProtocol(
        com.zkjg.generated.ledger.v1.CreateProtocolRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateProtocolMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 批量新建存证协议
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.ledger.v1.BatchCreateProtocolResponse> batchCreateProtocol(
        com.zkjg.generated.ledger.v1.BatchCreateProtocolRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getBatchCreateProtocolMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 更新存证协议
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.ledger.v1.UpdateProtocolResponse> updateProtocol(
        com.zkjg.generated.ledger.v1.UpdateProtocolRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateProtocolMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 批量更新存证协议
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.ledger.v1.BatchUpdateProtocolResponse> batchUpdateProtocol(
        com.zkjg.generated.ledger.v1.BatchUpdateProtocolRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getBatchUpdateProtocolMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 查询存证协议内容
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.ledger.v1.ReadProtocolResponse> readProtocol(
        com.zkjg.generated.ledger.v1.ReadProtocolRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getReadProtocolMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 创建存证业务合约
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.ledger.v1.CreateBusinessResponse> createBusiness(
        com.zkjg.generated.ledger.v1.CreateBusinessRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateBusinessMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * [basic, standard, ak-common-user, ak-baas, ak-data-on-chain]
     * 检查存证业务合约是否存在
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.ledger.v1.ExistsBusinessResponse> existsBusiness(
        com.zkjg.generated.ledger.v1.ExistsBusinessRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getExistsBusinessMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]
     * 存证数据
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.ledger.v1.WriteLedgerResponse> write(
        com.zkjg.generated.ledger.v1.WriteLedgerRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getWriteMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 批量存证数据
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.ledger.v1.BatchWriteLedgerResponse> batchWrite(
        com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getBatchWriteMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 同步批量存证数据
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.ledger.v1.SyncBatchWriteLedgerResponse> syncBatchWrite(
        com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getSyncBatchWriteMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 读取存证数据
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.ledger.v1.ReadLedgerResponse> read(
        com.zkjg.generated.ledger.v1.ReadLedgerRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getReadMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 解码多个存证的交易
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsResponse> decodeLedgerTransactions(
        com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDecodeLedgerTransactionsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-baas, ak-data-on-chain]
     * 解码单个存证的交易
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.ledger.v1.DecodeLedgerTransactionResponse> decodeLedgerTransaction(
        com.zkjg.generated.ledger.v1.DecodeLedgerTransactionRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDecodeLedgerTransactionMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_CREATE_PROTOCOL = 0;
  private static final int METHODID_BATCH_CREATE_PROTOCOL = 1;
  private static final int METHODID_UPDATE_PROTOCOL = 2;
  private static final int METHODID_BATCH_UPDATE_PROTOCOL = 3;
  private static final int METHODID_READ_PROTOCOL = 4;
  private static final int METHODID_CREATE_BUSINESS = 5;
  private static final int METHODID_EXISTS_BUSINESS = 6;
  private static final int METHODID_WRITE = 7;
  private static final int METHODID_BATCH_WRITE = 8;
  private static final int METHODID_SYNC_BATCH_WRITE = 9;
  private static final int METHODID_READ = 10;
  private static final int METHODID_DECODE_LEDGER_TRANSACTIONS = 11;
  private static final int METHODID_DECODE_LEDGER_TRANSACTION = 12;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_CREATE_PROTOCOL:
          serviceImpl.createProtocol((com.zkjg.generated.ledger.v1.CreateProtocolRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.CreateProtocolResponse>) responseObserver);
          break;
        case METHODID_BATCH_CREATE_PROTOCOL:
          serviceImpl.batchCreateProtocol((com.zkjg.generated.ledger.v1.BatchCreateProtocolRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.BatchCreateProtocolResponse>) responseObserver);
          break;
        case METHODID_UPDATE_PROTOCOL:
          serviceImpl.updateProtocol((com.zkjg.generated.ledger.v1.UpdateProtocolRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.UpdateProtocolResponse>) responseObserver);
          break;
        case METHODID_BATCH_UPDATE_PROTOCOL:
          serviceImpl.batchUpdateProtocol((com.zkjg.generated.ledger.v1.BatchUpdateProtocolRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.BatchUpdateProtocolResponse>) responseObserver);
          break;
        case METHODID_READ_PROTOCOL:
          serviceImpl.readProtocol((com.zkjg.generated.ledger.v1.ReadProtocolRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.ReadProtocolResponse>) responseObserver);
          break;
        case METHODID_CREATE_BUSINESS:
          serviceImpl.createBusiness((com.zkjg.generated.ledger.v1.CreateBusinessRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.CreateBusinessResponse>) responseObserver);
          break;
        case METHODID_EXISTS_BUSINESS:
          serviceImpl.existsBusiness((com.zkjg.generated.ledger.v1.ExistsBusinessRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.ExistsBusinessResponse>) responseObserver);
          break;
        case METHODID_WRITE:
          serviceImpl.write((com.zkjg.generated.ledger.v1.WriteLedgerRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.WriteLedgerResponse>) responseObserver);
          break;
        case METHODID_BATCH_WRITE:
          serviceImpl.batchWrite((com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.BatchWriteLedgerResponse>) responseObserver);
          break;
        case METHODID_SYNC_BATCH_WRITE:
          serviceImpl.syncBatchWrite((com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.SyncBatchWriteLedgerResponse>) responseObserver);
          break;
        case METHODID_READ:
          serviceImpl.read((com.zkjg.generated.ledger.v1.ReadLedgerRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.ReadLedgerResponse>) responseObserver);
          break;
        case METHODID_DECODE_LEDGER_TRANSACTIONS:
          serviceImpl.decodeLedgerTransactions((com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsResponse>) responseObserver);
          break;
        case METHODID_DECODE_LEDGER_TRANSACTION:
          serviceImpl.decodeLedgerTransaction((com.zkjg.generated.ledger.v1.DecodeLedgerTransactionRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.ledger.v1.DecodeLedgerTransactionResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getCreateProtocolMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.ledger.v1.CreateProtocolRequest,
              com.zkjg.generated.ledger.v1.CreateProtocolResponse>(
                service, METHODID_CREATE_PROTOCOL)))
        .addMethod(
          getBatchCreateProtocolMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.ledger.v1.BatchCreateProtocolRequest,
              com.zkjg.generated.ledger.v1.BatchCreateProtocolResponse>(
                service, METHODID_BATCH_CREATE_PROTOCOL)))
        .addMethod(
          getUpdateProtocolMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.ledger.v1.UpdateProtocolRequest,
              com.zkjg.generated.ledger.v1.UpdateProtocolResponse>(
                service, METHODID_UPDATE_PROTOCOL)))
        .addMethod(
          getBatchUpdateProtocolMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.ledger.v1.BatchUpdateProtocolRequest,
              com.zkjg.generated.ledger.v1.BatchUpdateProtocolResponse>(
                service, METHODID_BATCH_UPDATE_PROTOCOL)))
        .addMethod(
          getReadProtocolMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.ledger.v1.ReadProtocolRequest,
              com.zkjg.generated.ledger.v1.ReadProtocolResponse>(
                service, METHODID_READ_PROTOCOL)))
        .addMethod(
          getCreateBusinessMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.ledger.v1.CreateBusinessRequest,
              com.zkjg.generated.ledger.v1.CreateBusinessResponse>(
                service, METHODID_CREATE_BUSINESS)))
        .addMethod(
          getExistsBusinessMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.ledger.v1.ExistsBusinessRequest,
              com.zkjg.generated.ledger.v1.ExistsBusinessResponse>(
                service, METHODID_EXISTS_BUSINESS)))
        .addMethod(
          getWriteMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.ledger.v1.WriteLedgerRequest,
              com.zkjg.generated.ledger.v1.WriteLedgerResponse>(
                service, METHODID_WRITE)))
        .addMethod(
          getBatchWriteMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest,
              com.zkjg.generated.ledger.v1.BatchWriteLedgerResponse>(
                service, METHODID_BATCH_WRITE)))
        .addMethod(
          getSyncBatchWriteMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest,
              com.zkjg.generated.ledger.v1.SyncBatchWriteLedgerResponse>(
                service, METHODID_SYNC_BATCH_WRITE)))
        .addMethod(
          getReadMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.ledger.v1.ReadLedgerRequest,
              com.zkjg.generated.ledger.v1.ReadLedgerResponse>(
                service, METHODID_READ)))
        .addMethod(
          getDecodeLedgerTransactionsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsRequest,
              com.zkjg.generated.ledger.v1.DecodeLedgerTransactionsResponse>(
                service, METHODID_DECODE_LEDGER_TRANSACTIONS)))
        .addMethod(
          getDecodeLedgerTransactionMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.ledger.v1.DecodeLedgerTransactionRequest,
              com.zkjg.generated.ledger.v1.DecodeLedgerTransactionResponse>(
                service, METHODID_DECODE_LEDGER_TRANSACTION)))
        .build();
  }

  private static abstract class LedgerServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    LedgerServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.zkjg.generated.ledger.v1.LedgerProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("LedgerService");
    }
  }

  private static final class LedgerServiceFileDescriptorSupplier
      extends LedgerServiceBaseDescriptorSupplier {
    LedgerServiceFileDescriptorSupplier() {}
  }

  private static final class LedgerServiceMethodDescriptorSupplier
      extends LedgerServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    LedgerServiceMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (LedgerServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new LedgerServiceFileDescriptorSupplier())
              .addMethod(getCreateProtocolMethod())
              .addMethod(getBatchCreateProtocolMethod())
              .addMethod(getUpdateProtocolMethod())
              .addMethod(getBatchUpdateProtocolMethod())
              .addMethod(getReadProtocolMethod())
              .addMethod(getCreateBusinessMethod())
              .addMethod(getExistsBusinessMethod())
              .addMethod(getWriteMethod())
              .addMethod(getBatchWriteMethod())
              .addMethod(getSyncBatchWriteMethod())
              .addMethod(getReadMethod())
              .addMethod(getDecodeLedgerTransactionsMethod())
              .addMethod(getDecodeLedgerTransactionMethod())
              .build();
        }
      }
    }
    return result;
  }
}
