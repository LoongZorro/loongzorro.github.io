package com.zkjg.generated.contract.v1;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * 多语言智能合约服务
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.66.0)",
    comments = "Source: contract/v1/contract.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class MultiLangContractServiceGrpc {

  private MultiLangContractServiceGrpc() {}

  public static final java.lang.String SERVICE_NAME = "contract.v1.MultiLangContractService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.DeployMultiLangContractRequest,
      com.zkjg.generated.contract.v1.DeployMultiLangContractResponse> getDeployMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Deploy",
      requestType = com.zkjg.generated.contract.v1.DeployMultiLangContractRequest.class,
      responseType = com.zkjg.generated.contract.v1.DeployMultiLangContractResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.DeployMultiLangContractRequest,
      com.zkjg.generated.contract.v1.DeployMultiLangContractResponse> getDeployMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.DeployMultiLangContractRequest, com.zkjg.generated.contract.v1.DeployMultiLangContractResponse> getDeployMethod;
    if ((getDeployMethod = MultiLangContractServiceGrpc.getDeployMethod) == null) {
      synchronized (MultiLangContractServiceGrpc.class) {
        if ((getDeployMethod = MultiLangContractServiceGrpc.getDeployMethod) == null) {
          MultiLangContractServiceGrpc.getDeployMethod = getDeployMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.contract.v1.DeployMultiLangContractRequest, com.zkjg.generated.contract.v1.DeployMultiLangContractResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Deploy"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.contract.v1.DeployMultiLangContractRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.contract.v1.DeployMultiLangContractResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MultiLangContractServiceMethodDescriptorSupplier("Deploy"))
              .build();
        }
      }
    }
    return getDeployMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.CallMultiLangContractRequest,
      com.zkjg.generated.contract.v1.CallMultiLangContractResponse> getCallMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Call",
      requestType = com.zkjg.generated.contract.v1.CallMultiLangContractRequest.class,
      responseType = com.zkjg.generated.contract.v1.CallMultiLangContractResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.CallMultiLangContractRequest,
      com.zkjg.generated.contract.v1.CallMultiLangContractResponse> getCallMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.CallMultiLangContractRequest, com.zkjg.generated.contract.v1.CallMultiLangContractResponse> getCallMethod;
    if ((getCallMethod = MultiLangContractServiceGrpc.getCallMethod) == null) {
      synchronized (MultiLangContractServiceGrpc.class) {
        if ((getCallMethod = MultiLangContractServiceGrpc.getCallMethod) == null) {
          MultiLangContractServiceGrpc.getCallMethod = getCallMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.contract.v1.CallMultiLangContractRequest, com.zkjg.generated.contract.v1.CallMultiLangContractResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Call"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.contract.v1.CallMultiLangContractRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.contract.v1.CallMultiLangContractResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MultiLangContractServiceMethodDescriptorSupplier("Call"))
              .build();
        }
      }
    }
    return getCallMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.UpgradeMultiLangContractRequest,
      com.zkjg.generated.contract.v1.UpgradeMultiLangContractResponse> getUpgradeMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Upgrade",
      requestType = com.zkjg.generated.contract.v1.UpgradeMultiLangContractRequest.class,
      responseType = com.zkjg.generated.contract.v1.UpgradeMultiLangContractResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.UpgradeMultiLangContractRequest,
      com.zkjg.generated.contract.v1.UpgradeMultiLangContractResponse> getUpgradeMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.UpgradeMultiLangContractRequest, com.zkjg.generated.contract.v1.UpgradeMultiLangContractResponse> getUpgradeMethod;
    if ((getUpgradeMethod = MultiLangContractServiceGrpc.getUpgradeMethod) == null) {
      synchronized (MultiLangContractServiceGrpc.class) {
        if ((getUpgradeMethod = MultiLangContractServiceGrpc.getUpgradeMethod) == null) {
          MultiLangContractServiceGrpc.getUpgradeMethod = getUpgradeMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.contract.v1.UpgradeMultiLangContractRequest, com.zkjg.generated.contract.v1.UpgradeMultiLangContractResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Upgrade"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.contract.v1.UpgradeMultiLangContractRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.contract.v1.UpgradeMultiLangContractResponse.getDefaultInstance()))
              .setSchemaDescriptor(new MultiLangContractServiceMethodDescriptorSupplier("Upgrade"))
              .build();
        }
      }
    }
    return getUpgradeMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static MultiLangContractServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<MultiLangContractServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<MultiLangContractServiceStub>() {
        @java.lang.Override
        public MultiLangContractServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new MultiLangContractServiceStub(channel, callOptions);
        }
      };
    return MultiLangContractServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static MultiLangContractServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<MultiLangContractServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<MultiLangContractServiceBlockingStub>() {
        @java.lang.Override
        public MultiLangContractServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new MultiLangContractServiceBlockingStub(channel, callOptions);
        }
      };
    return MultiLangContractServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static MultiLangContractServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<MultiLangContractServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<MultiLangContractServiceFutureStub>() {
        @java.lang.Override
        public MultiLangContractServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new MultiLangContractServiceFutureStub(channel, callOptions);
        }
      };
    return MultiLangContractServiceFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * 多语言智能合约服务
   * </pre>
   */
  public interface AsyncService {

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 部署多语言智能合约（支持java和go）
     * </pre>
     */
    default void deploy(com.zkjg.generated.contract.v1.DeployMultiLangContractRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.DeployMultiLangContractResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeployMethod(), responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 调用多语言智能合约（支持java和go）
     * </pre>
     */
    default void call(com.zkjg.generated.contract.v1.CallMultiLangContractRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.CallMultiLangContractResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCallMethod(), responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 升级多语言智能合约（支持java和go）
     * </pre>
     */
    default void upgrade(com.zkjg.generated.contract.v1.UpgradeMultiLangContractRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.UpgradeMultiLangContractResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpgradeMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service MultiLangContractService.
   * <pre>
   * 多语言智能合约服务
   * </pre>
   */
  public static abstract class MultiLangContractServiceImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return MultiLangContractServiceGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service MultiLangContractService.
   * <pre>
   * 多语言智能合约服务
   * </pre>
   */
  public static final class MultiLangContractServiceStub
      extends io.grpc.stub.AbstractAsyncStub<MultiLangContractServiceStub> {
    private MultiLangContractServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected MultiLangContractServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new MultiLangContractServiceStub(channel, callOptions);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 部署多语言智能合约（支持java和go）
     * </pre>
     */
    public void deploy(com.zkjg.generated.contract.v1.DeployMultiLangContractRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.DeployMultiLangContractResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeployMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 调用多语言智能合约（支持java和go）
     * </pre>
     */
    public void call(com.zkjg.generated.contract.v1.CallMultiLangContractRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.CallMultiLangContractResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCallMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 升级多语言智能合约（支持java和go）
     * </pre>
     */
    public void upgrade(com.zkjg.generated.contract.v1.UpgradeMultiLangContractRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.UpgradeMultiLangContractResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpgradeMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service MultiLangContractService.
   * <pre>
   * 多语言智能合约服务
   * </pre>
   */
  public static final class MultiLangContractServiceBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<MultiLangContractServiceBlockingStub> {
    private MultiLangContractServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected MultiLangContractServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new MultiLangContractServiceBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 部署多语言智能合约（支持java和go）
     * </pre>
     */
    public com.zkjg.generated.contract.v1.DeployMultiLangContractResponse deploy(com.zkjg.generated.contract.v1.DeployMultiLangContractRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeployMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 调用多语言智能合约（支持java和go）
     * </pre>
     */
    public com.zkjg.generated.contract.v1.CallMultiLangContractResponse call(com.zkjg.generated.contract.v1.CallMultiLangContractRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCallMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 升级多语言智能合约（支持java和go）
     * </pre>
     */
    public com.zkjg.generated.contract.v1.UpgradeMultiLangContractResponse upgrade(com.zkjg.generated.contract.v1.UpgradeMultiLangContractRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpgradeMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service MultiLangContractService.
   * <pre>
   * 多语言智能合约服务
   * </pre>
   */
  public static final class MultiLangContractServiceFutureStub
      extends io.grpc.stub.AbstractFutureStub<MultiLangContractServiceFutureStub> {
    private MultiLangContractServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected MultiLangContractServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new MultiLangContractServiceFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 部署多语言智能合约（支持java和go）
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.contract.v1.DeployMultiLangContractResponse> deploy(
        com.zkjg.generated.contract.v1.DeployMultiLangContractRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeployMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 调用多语言智能合约（支持java和go）
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.contract.v1.CallMultiLangContractResponse> call(
        com.zkjg.generated.contract.v1.CallMultiLangContractRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCallMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 升级多语言智能合约（支持java和go）
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.contract.v1.UpgradeMultiLangContractResponse> upgrade(
        com.zkjg.generated.contract.v1.UpgradeMultiLangContractRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpgradeMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_DEPLOY = 0;
  private static final int METHODID_CALL = 1;
  private static final int METHODID_UPGRADE = 2;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_DEPLOY:
          serviceImpl.deploy((com.zkjg.generated.contract.v1.DeployMultiLangContractRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.DeployMultiLangContractResponse>) responseObserver);
          break;
        case METHODID_CALL:
          serviceImpl.call((com.zkjg.generated.contract.v1.CallMultiLangContractRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.CallMultiLangContractResponse>) responseObserver);
          break;
        case METHODID_UPGRADE:
          serviceImpl.upgrade((com.zkjg.generated.contract.v1.UpgradeMultiLangContractRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.UpgradeMultiLangContractResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getDeployMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.contract.v1.DeployMultiLangContractRequest,
              com.zkjg.generated.contract.v1.DeployMultiLangContractResponse>(
                service, METHODID_DEPLOY)))
        .addMethod(
          getCallMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.contract.v1.CallMultiLangContractRequest,
              com.zkjg.generated.contract.v1.CallMultiLangContractResponse>(
                service, METHODID_CALL)))
        .addMethod(
          getUpgradeMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.contract.v1.UpgradeMultiLangContractRequest,
              com.zkjg.generated.contract.v1.UpgradeMultiLangContractResponse>(
                service, METHODID_UPGRADE)))
        .build();
  }

  private static abstract class MultiLangContractServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    MultiLangContractServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.zkjg.generated.contract.v1.ContractProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("MultiLangContractService");
    }
  }

  private static final class MultiLangContractServiceFileDescriptorSupplier
      extends MultiLangContractServiceBaseDescriptorSupplier {
    MultiLangContractServiceFileDescriptorSupplier() {}
  }

  private static final class MultiLangContractServiceMethodDescriptorSupplier
      extends MultiLangContractServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    MultiLangContractServiceMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (MultiLangContractServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new MultiLangContractServiceFileDescriptorSupplier())
              .addMethod(getDeployMethod())
              .addMethod(getCallMethod())
              .addMethod(getUpgradeMethod())
              .build();
        }
      }
    }
    return result;
  }
}
