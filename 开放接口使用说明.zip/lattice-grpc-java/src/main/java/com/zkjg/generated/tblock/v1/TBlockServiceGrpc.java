package com.zkjg.generated.tblock.v1;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.66.0)",
    comments = "Source: tblock/v1/tblock.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class TBlockServiceGrpc {

  private TBlockServiceGrpc() {}

  public static final java.lang.String SERVICE_NAME = "tblock.v1.TBlockService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.tblock.v1.TransferRequest,
      com.zkjg.generated.tblock.v1.TransferResponse> getTransferMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Transfer",
      requestType = com.zkjg.generated.tblock.v1.TransferRequest.class,
      responseType = com.zkjg.generated.tblock.v1.TransferResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.tblock.v1.TransferRequest,
      com.zkjg.generated.tblock.v1.TransferResponse> getTransferMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.tblock.v1.TransferRequest, com.zkjg.generated.tblock.v1.TransferResponse> getTransferMethod;
    if ((getTransferMethod = TBlockServiceGrpc.getTransferMethod) == null) {
      synchronized (TBlockServiceGrpc.class) {
        if ((getTransferMethod = TBlockServiceGrpc.getTransferMethod) == null) {
          TBlockServiceGrpc.getTransferMethod = getTransferMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.tblock.v1.TransferRequest, com.zkjg.generated.tblock.v1.TransferResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Transfer"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.tblock.v1.TransferRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.tblock.v1.TransferResponse.getDefaultInstance()))
              .setSchemaDescriptor(new TBlockServiceMethodDescriptorSupplier("Transfer"))
              .build();
        }
      }
    }
    return getTransferMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.tblock.v1.QueryTBlockRequest,
      com.zkjg.generated.tblock.v1.QueryTBlockResponse> getQueryMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Query",
      requestType = com.zkjg.generated.tblock.v1.QueryTBlockRequest.class,
      responseType = com.zkjg.generated.tblock.v1.QueryTBlockResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.tblock.v1.QueryTBlockRequest,
      com.zkjg.generated.tblock.v1.QueryTBlockResponse> getQueryMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.tblock.v1.QueryTBlockRequest, com.zkjg.generated.tblock.v1.QueryTBlockResponse> getQueryMethod;
    if ((getQueryMethod = TBlockServiceGrpc.getQueryMethod) == null) {
      synchronized (TBlockServiceGrpc.class) {
        if ((getQueryMethod = TBlockServiceGrpc.getQueryMethod) == null) {
          TBlockServiceGrpc.getQueryMethod = getQueryMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.tblock.v1.QueryTBlockRequest, com.zkjg.generated.tblock.v1.QueryTBlockResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Query"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.tblock.v1.QueryTBlockRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.tblock.v1.QueryTBlockResponse.getDefaultInstance()))
              .setSchemaDescriptor(new TBlockServiceMethodDescriptorSupplier("Query"))
              .build();
        }
      }
    }
    return getQueryMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.tblock.v1.DetailsTBlockRequest,
      com.zkjg.generated.tblock.v1.DetailsTBlockResponse> getDetailsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Details",
      requestType = com.zkjg.generated.tblock.v1.DetailsTBlockRequest.class,
      responseType = com.zkjg.generated.tblock.v1.DetailsTBlockResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.tblock.v1.DetailsTBlockRequest,
      com.zkjg.generated.tblock.v1.DetailsTBlockResponse> getDetailsMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.tblock.v1.DetailsTBlockRequest, com.zkjg.generated.tblock.v1.DetailsTBlockResponse> getDetailsMethod;
    if ((getDetailsMethod = TBlockServiceGrpc.getDetailsMethod) == null) {
      synchronized (TBlockServiceGrpc.class) {
        if ((getDetailsMethod = TBlockServiceGrpc.getDetailsMethod) == null) {
          TBlockServiceGrpc.getDetailsMethod = getDetailsMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.tblock.v1.DetailsTBlockRequest, com.zkjg.generated.tblock.v1.DetailsTBlockResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Details"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.tblock.v1.DetailsTBlockRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.tblock.v1.DetailsTBlockResponse.getDefaultInstance()))
              .setSchemaDescriptor(new TBlockServiceMethodDescriptorSupplier("Details"))
              .build();
        }
      }
    }
    return getDetailsMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static TBlockServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<TBlockServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<TBlockServiceStub>() {
        @java.lang.Override
        public TBlockServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new TBlockServiceStub(channel, callOptions);
        }
      };
    return TBlockServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static TBlockServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<TBlockServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<TBlockServiceBlockingStub>() {
        @java.lang.Override
        public TBlockServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new TBlockServiceBlockingStub(channel, callOptions);
        }
      };
    return TBlockServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static TBlockServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<TBlockServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<TBlockServiceFutureStub>() {
        @java.lang.Override
        public TBlockServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new TBlockServiceFutureStub(channel, callOptions);
        }
      };
    return TBlockServiceFutureStub.newStub(factory, channel);
  }

  /**
   */
  public interface AsyncService {

    /**
     * <pre>
     * 转账
     * </pre>
     */
    default void transfer(com.zkjg.generated.tblock.v1.TransferRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.tblock.v1.TransferResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getTransferMethod(), responseObserver);
    }

    /**
     * <pre>
     * 查询交易
     * </pre>
     */
    default void query(com.zkjg.generated.tblock.v1.QueryTBlockRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.tblock.v1.QueryTBlockResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getQueryMethod(), responseObserver);
    }

    /**
     * <pre>
     * 查询交易详情
     * </pre>
     */
    default void details(com.zkjg.generated.tblock.v1.DetailsTBlockRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.tblock.v1.DetailsTBlockResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDetailsMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service TBlockService.
   */
  public static abstract class TBlockServiceImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return TBlockServiceGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service TBlockService.
   */
  public static final class TBlockServiceStub
      extends io.grpc.stub.AbstractAsyncStub<TBlockServiceStub> {
    private TBlockServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected TBlockServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new TBlockServiceStub(channel, callOptions);
    }

    /**
     * <pre>
     * 转账
     * </pre>
     */
    public void transfer(com.zkjg.generated.tblock.v1.TransferRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.tblock.v1.TransferResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getTransferMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * 查询交易
     * </pre>
     */
    public void query(com.zkjg.generated.tblock.v1.QueryTBlockRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.tblock.v1.QueryTBlockResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getQueryMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * 查询交易详情
     * </pre>
     */
    public void details(com.zkjg.generated.tblock.v1.DetailsTBlockRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.tblock.v1.DetailsTBlockResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDetailsMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service TBlockService.
   */
  public static final class TBlockServiceBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<TBlockServiceBlockingStub> {
    private TBlockServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected TBlockServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new TBlockServiceBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * 转账
     * </pre>
     */
    public com.zkjg.generated.tblock.v1.TransferResponse transfer(com.zkjg.generated.tblock.v1.TransferRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getTransferMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * 查询交易
     * </pre>
     */
    public com.zkjg.generated.tblock.v1.QueryTBlockResponse query(com.zkjg.generated.tblock.v1.QueryTBlockRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getQueryMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * 查询交易详情
     * </pre>
     */
    public com.zkjg.generated.tblock.v1.DetailsTBlockResponse details(com.zkjg.generated.tblock.v1.DetailsTBlockRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDetailsMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service TBlockService.
   */
  public static final class TBlockServiceFutureStub
      extends io.grpc.stub.AbstractFutureStub<TBlockServiceFutureStub> {
    private TBlockServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected TBlockServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new TBlockServiceFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * 转账
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.tblock.v1.TransferResponse> transfer(
        com.zkjg.generated.tblock.v1.TransferRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getTransferMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * 查询交易
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.tblock.v1.QueryTBlockResponse> query(
        com.zkjg.generated.tblock.v1.QueryTBlockRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getQueryMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * 查询交易详情
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.tblock.v1.DetailsTBlockResponse> details(
        com.zkjg.generated.tblock.v1.DetailsTBlockRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDetailsMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_TRANSFER = 0;
  private static final int METHODID_QUERY = 1;
  private static final int METHODID_DETAILS = 2;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_TRANSFER:
          serviceImpl.transfer((com.zkjg.generated.tblock.v1.TransferRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.tblock.v1.TransferResponse>) responseObserver);
          break;
        case METHODID_QUERY:
          serviceImpl.query((com.zkjg.generated.tblock.v1.QueryTBlockRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.tblock.v1.QueryTBlockResponse>) responseObserver);
          break;
        case METHODID_DETAILS:
          serviceImpl.details((com.zkjg.generated.tblock.v1.DetailsTBlockRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.tblock.v1.DetailsTBlockResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getTransferMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.tblock.v1.TransferRequest,
              com.zkjg.generated.tblock.v1.TransferResponse>(
                service, METHODID_TRANSFER)))
        .addMethod(
          getQueryMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.tblock.v1.QueryTBlockRequest,
              com.zkjg.generated.tblock.v1.QueryTBlockResponse>(
                service, METHODID_QUERY)))
        .addMethod(
          getDetailsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.tblock.v1.DetailsTBlockRequest,
              com.zkjg.generated.tblock.v1.DetailsTBlockResponse>(
                service, METHODID_DETAILS)))
        .build();
  }

  private static abstract class TBlockServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    TBlockServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.zkjg.generated.tblock.v1.TblockProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("TBlockService");
    }
  }

  private static final class TBlockServiceFileDescriptorSupplier
      extends TBlockServiceBaseDescriptorSupplier {
    TBlockServiceFileDescriptorSupplier() {}
  }

  private static final class TBlockServiceMethodDescriptorSupplier
      extends TBlockServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    TBlockServiceMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (TBlockServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new TBlockServiceFileDescriptorSupplier())
              .addMethod(getTransferMethod())
              .addMethod(getQueryMethod())
              .addMethod(getDetailsMethod())
              .build();
        }
      }
    }
    return result;
  }
}
