package com.zkjg.generated.contract.v1;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * 合约服务
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.66.0)",
    comments = "Source: contract/v1/contract.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class ContractServiceGrpc {

  private ContractServiceGrpc() {}

  public static final java.lang.String SERVICE_NAME = "contract.v1.ContractService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.DeployContractRequest,
      com.zkjg.generated.contract.v1.DeployContractResponse> getDeployMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Deploy",
      requestType = com.zkjg.generated.contract.v1.DeployContractRequest.class,
      responseType = com.zkjg.generated.contract.v1.DeployContractResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.DeployContractRequest,
      com.zkjg.generated.contract.v1.DeployContractResponse> getDeployMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.DeployContractRequest, com.zkjg.generated.contract.v1.DeployContractResponse> getDeployMethod;
    if ((getDeployMethod = ContractServiceGrpc.getDeployMethod) == null) {
      synchronized (ContractServiceGrpc.class) {
        if ((getDeployMethod = ContractServiceGrpc.getDeployMethod) == null) {
          ContractServiceGrpc.getDeployMethod = getDeployMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.contract.v1.DeployContractRequest, com.zkjg.generated.contract.v1.DeployContractResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Deploy"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.contract.v1.DeployContractRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.contract.v1.DeployContractResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ContractServiceMethodDescriptorSupplier("Deploy"))
              .build();
        }
      }
    }
    return getDeployMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.CallContractRequest,
      com.zkjg.generated.contract.v1.CallContractResponse> getCallMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Call",
      requestType = com.zkjg.generated.contract.v1.CallContractRequest.class,
      responseType = com.zkjg.generated.contract.v1.CallContractResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.CallContractRequest,
      com.zkjg.generated.contract.v1.CallContractResponse> getCallMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.CallContractRequest, com.zkjg.generated.contract.v1.CallContractResponse> getCallMethod;
    if ((getCallMethod = ContractServiceGrpc.getCallMethod) == null) {
      synchronized (ContractServiceGrpc.class) {
        if ((getCallMethod = ContractServiceGrpc.getCallMethod) == null) {
          ContractServiceGrpc.getCallMethod = getCallMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.contract.v1.CallContractRequest, com.zkjg.generated.contract.v1.CallContractResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Call"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.contract.v1.CallContractRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.contract.v1.CallContractResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ContractServiceMethodDescriptorSupplier("Call"))
              .build();
        }
      }
    }
    return getCallMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.PreCallContractRequest,
      com.zkjg.generated.contract.v1.PreCallContractResponse> getPreCallMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "PreCall",
      requestType = com.zkjg.generated.contract.v1.PreCallContractRequest.class,
      responseType = com.zkjg.generated.contract.v1.PreCallContractResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.PreCallContractRequest,
      com.zkjg.generated.contract.v1.PreCallContractResponse> getPreCallMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.PreCallContractRequest, com.zkjg.generated.contract.v1.PreCallContractResponse> getPreCallMethod;
    if ((getPreCallMethod = ContractServiceGrpc.getPreCallMethod) == null) {
      synchronized (ContractServiceGrpc.class) {
        if ((getPreCallMethod = ContractServiceGrpc.getPreCallMethod) == null) {
          ContractServiceGrpc.getPreCallMethod = getPreCallMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.contract.v1.PreCallContractRequest, com.zkjg.generated.contract.v1.PreCallContractResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "PreCall"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.contract.v1.PreCallContractRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.contract.v1.PreCallContractResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ContractServiceMethodDescriptorSupplier("PreCall"))
              .build();
        }
      }
    }
    return getPreCallMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.UpgradeContractRequest,
      com.zkjg.generated.contract.v1.UpgradeContractResponse> getUpgradeMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Upgrade",
      requestType = com.zkjg.generated.contract.v1.UpgradeContractRequest.class,
      responseType = com.zkjg.generated.contract.v1.UpgradeContractResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.UpgradeContractRequest,
      com.zkjg.generated.contract.v1.UpgradeContractResponse> getUpgradeMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.UpgradeContractRequest, com.zkjg.generated.contract.v1.UpgradeContractResponse> getUpgradeMethod;
    if ((getUpgradeMethod = ContractServiceGrpc.getUpgradeMethod) == null) {
      synchronized (ContractServiceGrpc.class) {
        if ((getUpgradeMethod = ContractServiceGrpc.getUpgradeMethod) == null) {
          ContractServiceGrpc.getUpgradeMethod = getUpgradeMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.contract.v1.UpgradeContractRequest, com.zkjg.generated.contract.v1.UpgradeContractResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Upgrade"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.contract.v1.UpgradeContractRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.contract.v1.UpgradeContractResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ContractServiceMethodDescriptorSupplier("Upgrade"))
              .build();
        }
      }
    }
    return getUpgradeMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.FreezeContractRequest,
      com.zkjg.generated.contract.v1.FreezeContractResponse> getFreezeMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Freeze",
      requestType = com.zkjg.generated.contract.v1.FreezeContractRequest.class,
      responseType = com.zkjg.generated.contract.v1.FreezeContractResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.FreezeContractRequest,
      com.zkjg.generated.contract.v1.FreezeContractResponse> getFreezeMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.FreezeContractRequest, com.zkjg.generated.contract.v1.FreezeContractResponse> getFreezeMethod;
    if ((getFreezeMethod = ContractServiceGrpc.getFreezeMethod) == null) {
      synchronized (ContractServiceGrpc.class) {
        if ((getFreezeMethod = ContractServiceGrpc.getFreezeMethod) == null) {
          ContractServiceGrpc.getFreezeMethod = getFreezeMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.contract.v1.FreezeContractRequest, com.zkjg.generated.contract.v1.FreezeContractResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Freeze"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.contract.v1.FreezeContractRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.contract.v1.FreezeContractResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ContractServiceMethodDescriptorSupplier("Freeze"))
              .build();
        }
      }
    }
    return getFreezeMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.UnfreezeContractRequest,
      com.zkjg.generated.contract.v1.UnfreezeContractResponse> getUnfreezeMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Unfreeze",
      requestType = com.zkjg.generated.contract.v1.UnfreezeContractRequest.class,
      responseType = com.zkjg.generated.contract.v1.UnfreezeContractResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.UnfreezeContractRequest,
      com.zkjg.generated.contract.v1.UnfreezeContractResponse> getUnfreezeMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.UnfreezeContractRequest, com.zkjg.generated.contract.v1.UnfreezeContractResponse> getUnfreezeMethod;
    if ((getUnfreezeMethod = ContractServiceGrpc.getUnfreezeMethod) == null) {
      synchronized (ContractServiceGrpc.class) {
        if ((getUnfreezeMethod = ContractServiceGrpc.getUnfreezeMethod) == null) {
          ContractServiceGrpc.getUnfreezeMethod = getUnfreezeMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.contract.v1.UnfreezeContractRequest, com.zkjg.generated.contract.v1.UnfreezeContractResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Unfreeze"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.contract.v1.UnfreezeContractRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.contract.v1.UnfreezeContractResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ContractServiceMethodDescriptorSupplier("Unfreeze"))
              .build();
        }
      }
    }
    return getUnfreezeMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.RevokeContractRequest,
      com.zkjg.generated.contract.v1.RevokeContractResponse> getRevokeMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Revoke",
      requestType = com.zkjg.generated.contract.v1.RevokeContractRequest.class,
      responseType = com.zkjg.generated.contract.v1.RevokeContractResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.RevokeContractRequest,
      com.zkjg.generated.contract.v1.RevokeContractResponse> getRevokeMethod() {
    io.grpc.MethodDescriptor<com.zkjg.generated.contract.v1.RevokeContractRequest, com.zkjg.generated.contract.v1.RevokeContractResponse> getRevokeMethod;
    if ((getRevokeMethod = ContractServiceGrpc.getRevokeMethod) == null) {
      synchronized (ContractServiceGrpc.class) {
        if ((getRevokeMethod = ContractServiceGrpc.getRevokeMethod) == null) {
          ContractServiceGrpc.getRevokeMethod = getRevokeMethod =
              io.grpc.MethodDescriptor.<com.zkjg.generated.contract.v1.RevokeContractRequest, com.zkjg.generated.contract.v1.RevokeContractResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Revoke"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.contract.v1.RevokeContractRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.zkjg.generated.contract.v1.RevokeContractResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ContractServiceMethodDescriptorSupplier("Revoke"))
              .build();
        }
      }
    }
    return getRevokeMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static ContractServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ContractServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ContractServiceStub>() {
        @java.lang.Override
        public ContractServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ContractServiceStub(channel, callOptions);
        }
      };
    return ContractServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static ContractServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ContractServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ContractServiceBlockingStub>() {
        @java.lang.Override
        public ContractServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ContractServiceBlockingStub(channel, callOptions);
        }
      };
    return ContractServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static ContractServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ContractServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ContractServiceFutureStub>() {
        @java.lang.Override
        public ContractServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ContractServiceFutureStub(channel, callOptions);
        }
      };
    return ContractServiceFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * 合约服务
   * </pre>
   */
  public interface AsyncService {

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 部署合约
     * </pre>
     */
    default void deploy(com.zkjg.generated.contract.v1.DeployContractRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.DeployContractResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeployMethod(), responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 调用合约
     * </pre>
     */
    default void call(com.zkjg.generated.contract.v1.CallContractRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.CallContractResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCallMethod(), responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 预调用合约
     * </pre>
     */
    default void preCall(com.zkjg.generated.contract.v1.PreCallContractRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.PreCallContractResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getPreCallMethod(), responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 升级合约
     * </pre>
     */
    default void upgrade(com.zkjg.generated.contract.v1.UpgradeContractRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.UpgradeContractResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpgradeMethod(), responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 冻结合约
     * </pre>
     */
    default void freeze(com.zkjg.generated.contract.v1.FreezeContractRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.FreezeContractResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getFreezeMethod(), responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 解冻合约
     * </pre>
     */
    default void unfreeze(com.zkjg.generated.contract.v1.UnfreezeContractRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.UnfreezeContractResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUnfreezeMethod(), responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 吊销合约
     * </pre>
     */
    default void revoke(com.zkjg.generated.contract.v1.RevokeContractRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.RevokeContractResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getRevokeMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service ContractService.
   * <pre>
   * 合约服务
   * </pre>
   */
  public static abstract class ContractServiceImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return ContractServiceGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service ContractService.
   * <pre>
   * 合约服务
   * </pre>
   */
  public static final class ContractServiceStub
      extends io.grpc.stub.AbstractAsyncStub<ContractServiceStub> {
    private ContractServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ContractServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ContractServiceStub(channel, callOptions);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 部署合约
     * </pre>
     */
    public void deploy(com.zkjg.generated.contract.v1.DeployContractRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.DeployContractResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeployMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 调用合约
     * </pre>
     */
    public void call(com.zkjg.generated.contract.v1.CallContractRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.CallContractResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCallMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 预调用合约
     * </pre>
     */
    public void preCall(com.zkjg.generated.contract.v1.PreCallContractRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.PreCallContractResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getPreCallMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 升级合约
     * </pre>
     */
    public void upgrade(com.zkjg.generated.contract.v1.UpgradeContractRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.UpgradeContractResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpgradeMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 冻结合约
     * </pre>
     */
    public void freeze(com.zkjg.generated.contract.v1.FreezeContractRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.FreezeContractResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getFreezeMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 解冻合约
     * </pre>
     */
    public void unfreeze(com.zkjg.generated.contract.v1.UnfreezeContractRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.UnfreezeContractResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUnfreezeMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 吊销合约
     * </pre>
     */
    public void revoke(com.zkjg.generated.contract.v1.RevokeContractRequest request,
        io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.RevokeContractResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getRevokeMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service ContractService.
   * <pre>
   * 合约服务
   * </pre>
   */
  public static final class ContractServiceBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<ContractServiceBlockingStub> {
    private ContractServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ContractServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ContractServiceBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 部署合约
     * </pre>
     */
    public com.zkjg.generated.contract.v1.DeployContractResponse deploy(com.zkjg.generated.contract.v1.DeployContractRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeployMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 调用合约
     * </pre>
     */
    public com.zkjg.generated.contract.v1.CallContractResponse call(com.zkjg.generated.contract.v1.CallContractRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCallMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 预调用合约
     * </pre>
     */
    public com.zkjg.generated.contract.v1.PreCallContractResponse preCall(com.zkjg.generated.contract.v1.PreCallContractRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getPreCallMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 升级合约
     * </pre>
     */
    public com.zkjg.generated.contract.v1.UpgradeContractResponse upgrade(com.zkjg.generated.contract.v1.UpgradeContractRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpgradeMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 冻结合约
     * </pre>
     */
    public com.zkjg.generated.contract.v1.FreezeContractResponse freeze(com.zkjg.generated.contract.v1.FreezeContractRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getFreezeMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 解冻合约
     * </pre>
     */
    public com.zkjg.generated.contract.v1.UnfreezeContractResponse unfreeze(com.zkjg.generated.contract.v1.UnfreezeContractRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUnfreezeMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 吊销合约
     * </pre>
     */
    public com.zkjg.generated.contract.v1.RevokeContractResponse revoke(com.zkjg.generated.contract.v1.RevokeContractRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getRevokeMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service ContractService.
   * <pre>
   * 合约服务
   * </pre>
   */
  public static final class ContractServiceFutureStub
      extends io.grpc.stub.AbstractFutureStub<ContractServiceFutureStub> {
    private ContractServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ContractServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ContractServiceFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 部署合约
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.contract.v1.DeployContractResponse> deploy(
        com.zkjg.generated.contract.v1.DeployContractRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeployMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 调用合约
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.contract.v1.CallContractResponse> call(
        com.zkjg.generated.contract.v1.CallContractRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCallMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 预调用合约
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.contract.v1.PreCallContractResponse> preCall(
        com.zkjg.generated.contract.v1.PreCallContractRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getPreCallMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 升级合约
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.contract.v1.UpgradeContractResponse> upgrade(
        com.zkjg.generated.contract.v1.UpgradeContractRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpgradeMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 冻结合约
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.contract.v1.FreezeContractResponse> freeze(
        com.zkjg.generated.contract.v1.FreezeContractRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getFreezeMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 解冻合约
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.contract.v1.UnfreezeContractResponse> unfreeze(
        com.zkjg.generated.contract.v1.UnfreezeContractRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUnfreezeMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * [simple, basic, standard, ak-common-user, ak-baas, ak-data-on-chain]]
     * 吊销合约
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.zkjg.generated.contract.v1.RevokeContractResponse> revoke(
        com.zkjg.generated.contract.v1.RevokeContractRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getRevokeMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_DEPLOY = 0;
  private static final int METHODID_CALL = 1;
  private static final int METHODID_PRE_CALL = 2;
  private static final int METHODID_UPGRADE = 3;
  private static final int METHODID_FREEZE = 4;
  private static final int METHODID_UNFREEZE = 5;
  private static final int METHODID_REVOKE = 6;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_DEPLOY:
          serviceImpl.deploy((com.zkjg.generated.contract.v1.DeployContractRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.DeployContractResponse>) responseObserver);
          break;
        case METHODID_CALL:
          serviceImpl.call((com.zkjg.generated.contract.v1.CallContractRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.CallContractResponse>) responseObserver);
          break;
        case METHODID_PRE_CALL:
          serviceImpl.preCall((com.zkjg.generated.contract.v1.PreCallContractRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.PreCallContractResponse>) responseObserver);
          break;
        case METHODID_UPGRADE:
          serviceImpl.upgrade((com.zkjg.generated.contract.v1.UpgradeContractRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.UpgradeContractResponse>) responseObserver);
          break;
        case METHODID_FREEZE:
          serviceImpl.freeze((com.zkjg.generated.contract.v1.FreezeContractRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.FreezeContractResponse>) responseObserver);
          break;
        case METHODID_UNFREEZE:
          serviceImpl.unfreeze((com.zkjg.generated.contract.v1.UnfreezeContractRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.UnfreezeContractResponse>) responseObserver);
          break;
        case METHODID_REVOKE:
          serviceImpl.revoke((com.zkjg.generated.contract.v1.RevokeContractRequest) request,
              (io.grpc.stub.StreamObserver<com.zkjg.generated.contract.v1.RevokeContractResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getDeployMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.contract.v1.DeployContractRequest,
              com.zkjg.generated.contract.v1.DeployContractResponse>(
                service, METHODID_DEPLOY)))
        .addMethod(
          getCallMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.contract.v1.CallContractRequest,
              com.zkjg.generated.contract.v1.CallContractResponse>(
                service, METHODID_CALL)))
        .addMethod(
          getPreCallMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.contract.v1.PreCallContractRequest,
              com.zkjg.generated.contract.v1.PreCallContractResponse>(
                service, METHODID_PRE_CALL)))
        .addMethod(
          getUpgradeMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.contract.v1.UpgradeContractRequest,
              com.zkjg.generated.contract.v1.UpgradeContractResponse>(
                service, METHODID_UPGRADE)))
        .addMethod(
          getFreezeMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.contract.v1.FreezeContractRequest,
              com.zkjg.generated.contract.v1.FreezeContractResponse>(
                service, METHODID_FREEZE)))
        .addMethod(
          getUnfreezeMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.contract.v1.UnfreezeContractRequest,
              com.zkjg.generated.contract.v1.UnfreezeContractResponse>(
                service, METHODID_UNFREEZE)))
        .addMethod(
          getRevokeMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.zkjg.generated.contract.v1.RevokeContractRequest,
              com.zkjg.generated.contract.v1.RevokeContractResponse>(
                service, METHODID_REVOKE)))
        .build();
  }

  private static abstract class ContractServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    ContractServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.zkjg.generated.contract.v1.ContractProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("ContractService");
    }
  }

  private static final class ContractServiceFileDescriptorSupplier
      extends ContractServiceBaseDescriptorSupplier {
    ContractServiceFileDescriptorSupplier() {}
  }

  private static final class ContractServiceMethodDescriptorSupplier
      extends ContractServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    ContractServiceMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (ContractServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new ContractServiceFileDescriptorSupplier())
              .addMethod(getDeployMethod())
              .addMethod(getCallMethod())
              .addMethod(getPreCallMethod())
              .addMethod(getUpgradeMethod())
              .addMethod(getFreezeMethod())
              .addMethod(getUnfreezeMethod())
              .addMethod(getRevokeMethod())
              .build();
        }
      }
    }
    return result;
  }
}
