package com.zkjg.utils;

import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.encoders.Hex;
import org.bouncycastle.util.io.pem.PemObject;
import org.bouncycastle.util.io.pem.PemWriter;

import javax.crypto.Cipher;
import java.io.StringReader;
import java.io.StringWriter;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

public class RsaUtils {
    static {
        Security.addProvider(new BouncyCastleProvider());
    }

    private static final String ALGORITHM = "RSA";
    public static final String PUBLIC_KEY = "-----BEGIN RSA PUBLIC KEY-----\nMIIBCgKCAQEAvXtLdzDM/P6HknR8pAKRMgV2WzJPRTsqLrEd13RrQ8gdR7OplXzr\nWP/q3cd+75qWlyBLwAOAhpnaYEOHrvnfnLhf7UqUqNPOdNa/pBHo3ac/c4j3SAGF\nQuee5hLFiaJaaaW7CAwa2KUE+QCHqNSFLJD3aIGLnI1nHUnh/24RcnFZDewt/fQ8\nR3WVV2bu+MNpsN9FMTvJJi24AzogrKlWAdtrBLRV6JK9nT1BrFoBj2n/k+Koc6NY\nWfremQO8lUmyMaO5luEvgSg5Ky2KfCbBnTeB6pGUkvMf6oytj8UC4voSK27sMwy0\n5DaKTF3NWX6wj/vENgIPdVd29qnn/2qFOQIDAQAB\n-----END RSA PUBLIC KEY-----";
    private static final String PRIVATE_KEY = "-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAKCAQEAvXtLdzDM/P6HknR8pAKRMgV2WzJPRTsqLrEd13RrQ8gdR7Op\nlXzrWP/q3cd+75qWlyBLwAOAhpnaYEOHrvnfnLhf7UqUqNPOdNa/pBHo3ac/c4j3\nSAGFQuee5hLFiaJaaaW7CAwa2KUE+QCHqNSFLJD3aIGLnI1nHUnh/24RcnFZDewt\n/fQ8R3WVV2bu+MNpsN9FMTvJJi24AzogrKlWAdtrBLRV6JK9nT1BrFoBj2n/k+Ko\nc6NYWfremQO8lUmyMaO5luEvgSg5Ky2KfCbBnTeB6pGUkvMf6oytj8UC4voSK27s\nMwy05DaKTF3NWX6wj/vENgIPdVd29qnn/2qFOQIDAQABAoIBAQCdfYVUJDO9dLGq\ngTe3+opEUVX2pvJMUMjW1lA/bHxbclEj76jcn1/eMZg9jjtrW8ofArDzf/Wr6uUf\nbgGw5e9+i6Dv0jWNvb60TmorLNeopAKRPR6LsvfYjDv+b0vRAiiz9xRls+n8d+yS\nKmaXZUzrpfJ94m7wSHeUWHyHmizWOQFlaA5h+oyv0EzZpo1AAy+A5R/e/DX1oqL8\nWs6f/qofuNrinKU0S1ZRgtWHtX42NrV76GuSC+vsNxyMTT/3J3f7lPNdiWHHCYIm\nC1l88oUYF8ypK6lG23n0+vk7jZbEPCd71Bc5BIVXyaaep8gjpOyWEjznhFPd3pNd\niLt2A3whAoGBAOjCuFQP32bcdl5+a4zrlxve0gs4ieIPGbQwxl+tkuNFaS8V4SOw\niqE3Msvx3InaehQbITxqIkZUys7o756M4UNQp2jNDFQeJeaA6Jm/5w3Dq3lOvwvX\nZK6yUG/uMTFWwKzOtwsfuqk5WBw0yvldkgkSL3tBvf5lj7E2yiWcO2BTAoGBANBm\nYOmi2EVL4WpPImBnZ49CG4KD0sbvj4Tl+byVmjd9iC2+EEFKfUoYGKN48Z2MwpkC\nLvulr4zZmSRjS+RDQBhkBs9nh6KmhLRrkZp8WilUPdi0hbYZyl5X+1swhyMptJ9W\nWPgi3kDsLhswSFDdv2LTHJ3Nko3MlR+DNdo64oLDAoGBAOaQ1HT40CydYGfURQdv\n69zAyUIyPGuA185lrmvijamx/TKWMtHetERkYF4j9HldwSYfhbnJzK/smIWDurFN\nDmtW/q5Sx86fmp2Nvltm/CLnW/mrZpX9RI/EtOdbhMFCFVRY5HsRcB7nXf960EFa\nTinMKNqo0eKpikBabL3619pfAoGAXK164cwKs96H83gXyJmTw3DZvRQUs2WsBKUl\nh8lcGNtZqUYCApc22rGWm3RYtwD3NYZ0EHNhe5j1cuo5wNxrb61kHe5jsmCtWXMR\nAIvWqNSO4IV/hTk49vXXkXkmT+vnKIkE7ezLvEGMS4kQT+4dg7xw2HioeSkHFEmM\ntG1FeHMCgYB7jTt/Yif6s5YCmYRQDazYWKc5alcXpUo0KHK0rfHhX/fwXw0uK5pa\nw/IgXt4+EomSyXOey/v5yAWOvat0LTFqk8UpJpb5CvUMJ/DKXKPrhC3BtwOZ9LeO\nA9mXKsx/htSgXRBCtGlVrZfVRn107t5pMTPq2PKDlpThmQbCdTBo6A==\n-----END RSA PRIVATE KEY-----";


    /**
     * 生成RSA的密钥对
     *
     * @return KeyPair
     */
    public static KeyPair generateRsaKeyPair() throws NoSuchAlgorithmException {
        KeyPairGenerator keypair = KeyPairGenerator.getInstance(ALGORITHM);
        keypair.initialize(2048); // key size: 1024/2048/4096
        return keypair.generateKeyPair();
    }

    /**
     * 将公钥转为PEM格式的字符串
     */
    public static String publicKeyToPem(PublicKey publicKey) throws Exception {
        X509EncodedKeySpec spec = new X509EncodedKeySpec(publicKey.getEncoded());
        PemObject pemObject = new PemObject("RSA PUBLIC KEY", spec.getEncoded());
        return writePemToString(pemObject);
    }

    /**
     * 将私钥转为PEM格式的字符串
     */
    public static String privateKeyToPem(PrivateKey privateKey) throws Exception {
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(privateKey.getEncoded());
        PemObject pemObject = new PemObject("RSA PRIVATE KEY", spec.getEncoded());
        return writePemToString(pemObject);
    }

    // 将PemObject转换为字符串
    public static String writePemToString(PemObject pemObject) throws Exception {
        StringWriter stringWriter = new StringWriter();
        try (PemWriter pemWriter = new PemWriter(stringWriter)) {
            pemWriter.writeObject(pemObject);
        }
        return stringWriter.toString();
    }

    /**
     * 将PEM格式的公钥转为PublicKey
     *
     * @param pemPublicKey pem格式的公钥
     * @return PublicKey
     */
    public static PublicKey publicKeyFromPem(String pemPublicKey) throws Exception {
        PEMParser pemParser = new PEMParser(new StringReader(pemPublicKey));
        JcaPEMKeyConverter converter = new JcaPEMKeyConverter().setProvider("BC");
        Object obj = pemParser.readObject();
        return converter.getPublicKey((SubjectPublicKeyInfo) obj);
    }

    /**
     * 将PEM格式的私钥转为PrivateKey
     */
    public static PrivateKey privateKeyFromPem(String pemPrivateKey) throws Exception {
        PEMParser pemParser = new PEMParser(new StringReader(pemPrivateKey));
        JcaPEMKeyConverter converter = new JcaPEMKeyConverter().setProvider("BC");
        Object obj = pemParser.readObject();
        return converter.getPrivateKey((PrivateKeyInfo) obj);
    }

    /**
     * RSA加密数据
     *
     * @param data      待加密的数据
     * @param publicKey pem公钥
     * @return 加密串，16进制
     */
    public static String encrypt(String data, String publicKey) throws Exception {
        X509EncodedKeySpec spec = new X509EncodedKeySpec(publicKeyFromPem(publicKey).getEncoded());
        KeyFactory keyFactory = KeyFactory.getInstance(ALGORITHM);
        PublicKey pk = keyFactory.generatePublic(spec);

        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, pk);
        byte[] bytes = cipher.doFinal(data.getBytes());
        return Base64.toBase64String(bytes);
    }

    /**
     * RSA解密数据
     *
     * @param cipherText 密文
     * @param privateKey pem 私钥
     * @return 解密后的数据
     */
    public static String decrypt(String cipherText, String privateKey) throws Exception {
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(privateKeyFromPem(privateKey).getEncoded());
        KeyFactory keyFactory = KeyFactory.getInstance(ALGORITHM);
        PrivateKey sk = keyFactory.generatePrivate(spec);

        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.DECRYPT_MODE, sk);
        byte[] bytes = cipher.doFinal(Base64.decode(cipherText));
        return Hex.toHexString(bytes);
    }

    public static void main(String[] args) throws Exception {
        KeyPair keyPair = generateRsaKeyPair();
        System.out.println(privateKeyToPem(keyPair.getPrivate()));
        System.out.println(publicKeyToPem(keyPair.getPublic()));
        System.out.println(encrypt("Root1234", PUBLIC_KEY));
    }
}
