package com.zkjg.utils;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.encoders.Hex;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;

/**
 * Symmetric encryption base on bouncycastle.
 */
public class SM4 extends BCProvider {

    private SM4() {
        // privatization construction method
    }

    private static final String ALGORITHM = "SM4";

    /**
     * 默认key长度，128bit = 16byte
     */
    private static final int DEFAULT_KEY_SIZE = 128;

    /**
     * generate key specify key size
     *
     * @param size bit
     * @return hex key
     */
    public static String generateKey(int size) {
        try {
            KeyGenerator keyGenerator = KeyGenerator.getInstance(ALGORITHM, BouncyCastleProvider.PROVIDER_NAME);
            keyGenerator.init(size, new SecureRandom());
            return Hex.toHexString(keyGenerator.generateKey().getEncoded());
        } catch (NoSuchAlgorithmException | NoSuchProviderException e) {
            throw new RuntimeException("NoSuchAlgorithmException or NoSuchProviderException");
        }
    }

    /**
     * generate key with default key size(128bit)
     *
     * @return hex key
     */
    public static String generateKey() {
        return generateKey(DEFAULT_KEY_SIZE);
    }

    /**
     * ECB模式
     */
    public static class ECB {
        private ECB() {
            // privatization construction method
        }

        /**
         * encrypt input byte array
         *
         * @param bytes byte array
         * @param key   key
         * @return hex string
         */
        public static byte[] encrypt(byte[] bytes, byte[] key) {
            return SM4.encrypt(Mode.ECB, bytes, key);
        }

        /**
         * decrypt cipher
         *
         * @param hexString hex string
         * @param key       key
         * @return source
         */
        public static byte[] decrypt(String hexString, String key) {
            return SM4.decrypt(Mode.ECB, hexString, key);
        }
    }

    /**
     * CBC模式
     */
    public static class CBC {
        private CBC() {
            // privatization construction method
        }

        /**
         * encrypt input byte array
         *
         * @param bytes byte array
         * @param key   key
         * @return hex string
         */
        public static byte[] encrypt(byte[] bytes, byte[] key) {
            return SM4.encrypt(Mode.CBC, bytes, key);
        }

        /**
         * decrypt cipher
         *
         * @param hexString hex string
         * @param key       key
         * @return source
         */
        public static byte[] decrypt(String hexString, String key) {
            return SM4.decrypt(Mode.CBC, hexString, key);
        }
    }

    /**
     * encrypt input byte array
     *
     * @param mode  模式
     * @param bytes byte array
     * @param key   key
     * @return hex string
     */
    public static byte[] encrypt(Mode mode, byte[] bytes, byte[] key) {
        try {
            Cipher cipher = Cipher.getInstance(mode.getValue(), BouncyCastleProvider.PROVIDER_NAME);
            Key sm4Key = new SecretKeySpec(key, ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, sm4Key);
            return cipher.doFinal(bytes);
        } catch (NoSuchAlgorithmException | NoSuchProviderException | NoSuchPaddingException | InvalidKeyException |
                 IllegalBlockSizeException | BadPaddingException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * decrypt cipher
     *
     * @param mode      模式
     * @param hexString hex string
     * @param key       key
     * @return source
     */
    public static byte[] decrypt(Mode mode, String hexString, String key) {
        byte[] decodedKey = Hex.decode(key);
        try {
            Cipher cipher = Cipher.getInstance(mode.getValue(), BouncyCastleProvider.PROVIDER_NAME);
            Key sm4Key = new SecretKeySpec(decodedKey, ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, sm4Key);
            return cipher.doFinal(Hex.decode(hexString));
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException |
                 BadPaddingException | NoSuchProviderException e) {
            throw new RuntimeException(e);
        }
    }

    @Getter
    @AllArgsConstructor
    public enum Mode {
        ECB("SM4/ECB/PKCS7Padding"),
        CBC("SM4/CBC/PKCS7Padding"),
        CFB("SM4/CFB/PKCS7Padding"),
        OFB("SM4/OFB/PKCS7Padding"),
        CTR("SM4/CTR/PKCS7Padding");

        private final String value;
    }
}
