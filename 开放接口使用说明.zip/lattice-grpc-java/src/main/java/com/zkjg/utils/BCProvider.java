package com.zkjg.utils;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

import java.security.Security;

public class BCProvider {

    static {
        Security.addProvider(new BouncyCastleProvider());
    }
}