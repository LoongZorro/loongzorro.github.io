package com.zkjg.utils;

import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.encoders.Hex;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.SecureRandom;
import java.util.Arrays;

public class Aes {

    private Aes() {
        // privatization construction method
    }

    public static class CTR {

        private CTR() {
            // privatization construction method
        }

        private static final String CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        private static final String AES_SUFFIX = "zlattice";
        private static final String HEX_PREFIX = "46434644";
        private static final String HEX_SUFFIX = "46454646";

        private static final int COUNTER_INITIAL_VALUE = 5;

        /**
         * 加解密私钥的key
         */
        private static final String KEY = "ca1c3a189e50f55b0c493db874ea0bec";

        /**
         * 加解密私钥的iv
         */
        private static final String IV = "ca1c3a189e50f55b0c493db874ea0bec";

        /**
         * 8: key default length
         *
         * @return String
         */
        public static String generateSecret() {
            return generateSecret(8);
        }

        /**
         * generate key
         *
         * @param len the length of key
         * @return String
         */
        public static String generateSecret(int len) {
            int maxPos = CHARS.length();
            StringBuilder code = new StringBuilder();
            for (int i = 0; i < len; i++) {
                int randomNum = generateRandomNum(0, maxPos - 1);
                char c = CHARS.charAt(randomNum);
                code.append(c);
            }
            return code.toString();
        }

        public static int generateRandomNum(int min, int max) {
            return (int) Math.floor(Math.random() * (max - min + 1) + min);
        }

        /**
         * AES CTR加密
         *
         * @param data source
         * @param key  key，16/24/32字节
         * @return String base64编码后的加密串
         */
        public static String encrypt(byte[] data, String key) {
            try {
                String hexData = HEX_PREFIX + Hex.toHexString(data) + HEX_SUFFIX;
                SecretKeySpec secretKeySpec = new SecretKeySpec((key + AES_SUFFIX).getBytes(), "AES");
                IvParameterSpec iv = new IvParameterSpec(counter());
                Cipher cipher = Cipher.getInstance("AES/CTR/NoPadding");
                cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, iv);
                byte[] result = cipher.doFinal(Hex.decode(hexData));
                return Base64.toBase64String(result);
            } catch (Exception e) {
                throw new RuntimeException("AES加密异常");
            }
        }

        /**
         * AES CTR解密
         *
         * @param data cipher base64编码的密文
         * @param key  key
         * @return String utf8编码后的字符串
         */
        public static String decrypt(String data, String key) {
            try {
                SecretKeySpec secretKeySpec = new SecretKeySpec((key + AES_SUFFIX).getBytes(), "AES");
                IvParameterSpec iv = new IvParameterSpec(counter());
                Cipher cipher = Cipher.getInstance("AES/CTR/NoPadding");
                cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, iv);
                byte[] result = cipher.doFinal(Base64.decode(data));
                if (result.length < 8) {
                    throw new RuntimeException("密文长度不足");
                }
                if (startsWith(result, new byte[]{70, 67, 70, 68}) && endsWith(result, new byte[]{70, 69, 70, 70})) {
                    byte[] bytes = Arrays.copyOfRange(result, 4, result.length - 4);
                    return new String(bytes);
                } else {
                    throw new RuntimeException("key错误");
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        private static boolean startsWith(byte[] array, byte[] prefix) {
            for (int i = 0; i < prefix.length; i++) {
                if (array[i] != prefix[i]) {
                    return false;
                }
            }
            return true;
        }

        private static boolean endsWith(byte[] array, byte[] suffix) {
            int offset = array.length - suffix.length;
            for (int i = 0; i < suffix.length; i++) {
                if (array[offset + i] != suffix[i]) {
                    return false;
                }
            }
            return true;
        }

        private static byte[] counter() {
            return counter(COUNTER_INITIAL_VALUE);
        }

        @SuppressWarnings("all")
        private static byte[] counter(int initialValue) {
            SecureRandom ivGenerator = new SecureRandom();

            final int ivLength = 16;
            int value = initialValue;
            byte[] iv = new byte[ivLength];
            ivGenerator.nextBytes(iv);
            for (int i = 15; i >= 0; --i) {
                iv[i] = (byte) (value % 256);
                value = value / 256;
            }
            return iv;
        }
    }

    public static void main(String[] args) {
        String key = "9jo29cr1";
        String data = "Hello World";
        String cipher = Aes.CTR.encrypt(data.getBytes(), key);
        System.out.println(cipher);
        String sourceData = Aes.CTR.decrypt(cipher, key);
        System.out.println(sourceData);
    }
}
