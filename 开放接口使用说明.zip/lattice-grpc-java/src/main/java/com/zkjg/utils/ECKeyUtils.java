package com.zkjg.utils;

import org.bouncycastle.jce.ECNamedCurveTable;
import org.bouncycastle.jce.spec.ECNamedCurveParameterSpec;
import org.bouncycastle.jce.spec.ECPrivateKeySpec;
import org.bouncycastle.jce.spec.ECPublicKeySpec;

import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.interfaces.ECPrivateKey;
import java.security.interfaces.ECPublicKey;

public class ECKeyUtils extends BCProvider {

    public static ECPrivateKey fromHexPrivateKey(String hexPrivateKey) {
        if (hexPrivateKey.length() != 64) {
            throw new IllegalArgumentException("Private key must be 64 hex characters");
        }

        BigInteger privateKeyD = new BigInteger(hexPrivateKey, 16);

        ECPrivateKeySpec privateKeySpec = new ECPrivateKeySpec(
                privateKeyD,
                ECNamedCurveTable.getParameterSpec("secp256r1")
        );

        try {
            KeyFactory keyFactory = KeyFactory.getInstance("EC", "BC");
            return (ECPrivateKey) keyFactory.generatePrivate(privateKeySpec);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static ECPublicKey fromUncompressedPublicKey(String hexPublicKey) {
        // Uncompressed public key, start with(04), the length is 130.
        if (hexPublicKey.length() != 130) {
            throw new IllegalArgumentException("Public key must be 130 hex characters (uncompressed format)");
        }

        // Remove the 04 at the beginning (uncompressed format identifier)
        String x = hexPublicKey.substring(2, 66);
        String y = hexPublicKey.substring(66, 130);

        // Convert to BigInteger
        BigInteger xBi = new BigInteger(x, 16);
        BigInteger yBi = new BigInteger(y, 16);
        // Get curve parameters
        ECNamedCurveParameterSpec params = ECNamedCurveTable.getParameterSpec("secp256r1");
        // Creating a public key point
        org.bouncycastle.math.ec.ECPoint point = params.getCurve().createPoint(xBi, yBi);
        // Creating a public key specification
        ECPublicKeySpec pubKeySpec = new ECPublicKeySpec(point, params);

        // Creating a public key
        try {
            KeyFactory keyFactory = KeyFactory.getInstance("EC", "BC");
            return (ECPublicKey) keyFactory.generatePublic(pubKeySpec);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // the length of private key hex string is 64, without prefix 0x
    public static String toHexPrivateKey(PrivateKey privateKey) {
        ECPrivateKey ecPrivateKey = (ECPrivateKey) privateKey;
        BigInteger s = ecPrivateKey.getS();
        return s.toString(16);
    }

    // the length of uncompressed public key hex string is 130, with fixed prefix 04(represent uncompressed)
    public static String toHexPublicKey(PublicKey publicKey) {
        ECPublicKey ecPublicKey = (ECPublicKey) publicKey;
        BigInteger x = ecPublicKey.getW().getAffineX();
        BigInteger y = ecPublicKey.getW().getAffineY();
        return "04" + x.toString(16) + y.toString(16);
    }
}