package com.zkjg.utils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;

import java.util.Calendar;
import java.util.Date;

public class JwtUtils {

    private static final int EXPIRATION_HOUR = 10;

    public static String generateToken() {
        try {
            Date now = new Date();
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(now);
            calendar.add(Calendar.HOUR_OF_DAY, EXPIRATION_HOUR);
            Date expirationAt = calendar.getTime();
            Algorithm algorithm = Algorithm.HMAC256("lnm_secret");
            return JWT.create()
                    .withExpiresAt(expirationAt)
                    .sign(algorithm);
        } catch (JWTCreationException exception) {
            // Invalid Signing configuration / Couldn't convert Claims.
            throw new RuntimeException(exception);
        }
    }
}
