package com.zkjg.utils;

import java.math.BigInteger;
import java.util.Arrays;

public class Base58 {

    private static final String ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
    private static final int BASE = ALPHABET.length();

    public static String encode(byte[] input) {
        BigInteger bi = new BigInteger(1, input);

        StringBuilder encoded = new StringBuilder();
        while (bi.compareTo(BigInteger.ZERO) > 0) {
            int remainder = bi.mod(BigInteger.valueOf(BASE)).intValue();
            encoded.insert(0, ALPHABET.charAt(remainder));
            bi = bi.divide(BigInteger.valueOf(BASE));
        }

        // Handle the case of leading zeros
        for (int i = 0; i < input.length && input[i] == 0; i++) {
            encoded.insert(0, ALPHABET.charAt(0)); // 对应 Base58 中的字符 '1'
        }

        return encoded.toString();
    }

    public static byte[] decode(String input) {
        BigInteger bi = BigInteger.ZERO;

        // 遍历输入字符串并根据 Base58 编码规则进行解码
        for (int i = 0; i < input.length(); i++) {
            int index = ALPHABET.indexOf(input.charAt(i));
            if (index == -1) {
                throw new IllegalArgumentException("Invalid character in Base58 string");
            }
            bi = bi.multiply(BigInteger.valueOf(BASE)).add(BigInteger.valueOf(index));
        }

        // Convert to a byte array
        byte[] decoded = bi.toByteArray();

        // Handle the case of leading zeros
        if (input.charAt(0) == ALPHABET.charAt(0)) {
            int leadingZeros = 0;
            while (leadingZeros < input.length() && input.charAt(leadingZeros) == ALPHABET.charAt(0)) {
                leadingZeros++;
            }
            decoded = Arrays.copyOfRange(decoded, 1, decoded.length);
            byte[] result = new byte[leadingZeros + decoded.length];
            System.arraycopy(decoded, 0, result, leadingZeros, decoded.length);
            decoded = result;
        }

        return decoded;
    }

    public static void main(String[] args) {
        // 测试 Base58 编码和解码
        String original = "Hello World";
        byte[] encodedBytes = original.getBytes();
        String encoded = encode(encodedBytes);
        System.out.println("Encoded: " + encoded);

        byte[] decodedBytes = decode(encoded);
        String decoded = new String(decodedBytes);
        System.out.println("Decoded: " + decoded);
    }
}