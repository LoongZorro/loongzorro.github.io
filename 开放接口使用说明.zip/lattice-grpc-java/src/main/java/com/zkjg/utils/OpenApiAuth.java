package com.zkjg.utils;


import com.zkjg.client.Config;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

public class OpenApiAuth {

    // 接口签名的
    private static final Map<String, String> AK_MAP = new HashMap<String, String>() {
        {
            put(Config.ACCESS_KEY_ID, Config.ACCESS_KEY_SECRET);
        }
    };


    private final static Charset UTF8 = StandardCharsets.UTF_8;

    /**
     * 生成消息认证码
     *
     * @param key 密钥
     * @param msg 消息
     */
    public static byte[] hmac256(byte[] key, String msg) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        SecretKeySpec secretKeySpec = new SecretKeySpec(key, mac.getAlgorithm());
        mac.init(secretKeySpec);
        return mac.doFinal(msg.getBytes(UTF8));
    }

    /**
     * 哈希
     *
     * @param msg 消息
     */
    public static String sha256Hex(String msg) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] d = md.digest(msg.getBytes(UTF8));
        return DatatypeConverter.printHexBinary(d).toLowerCase();
    }

    /**
     * 生成OpenAPI接口签名
     *
     * @param sk        加密后的私钥，不需要上链时可以为空
     * @param payload   Post的请求体，是proto中定义的RPC接口的请求参数，通过protobuf序列化为byte数组
     * @param timestamp 请求的时间戳
     * @param address   请求的账户地址
     * @return 签名
     */
    public static String generateSignature(String sk, String payload, String timestamp, String address) throws Exception {
        final String service = "nm"; // 此项固定为 nm
        final String algorithm = "JG-HMAC-SHA256"; // 此项暂定为 JG-HMAC-SHA256
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC")); // 注意时区，否则容易出错
        String date = sdf.format(new Date(Long.parseLong(timestamp + "000")));
        String accessKeyId = Config.ACCESS_KEY_ID;

        // First Step
        String httpRequestMethod = "POST";
        String canonicalUri = "/";
        String canonicalQueryString = "";

        String canonicalHeaders = generateCanonicalHeaders(sk, address, timestamp);
        String signedHeaders = generateSignedHeaders(sk, address);
        String hashedRequestPayload = sha256Hex(payload);
        String canonicalRequest = httpRequestMethod + "\n" + canonicalUri + "\n" + canonicalQueryString + "\n"
                + canonicalHeaders + "\n" + signedHeaders + "\n" + hashedRequestPayload;

        // Second Step
        String credentialScope = date + "/" + service + "/" + "jg_request";
        String hashedCanonicalRequest = sha256Hex(canonicalRequest);
        String stringToSign = algorithm + "\n" + timestamp + "\n" + credentialScope + "\n" + hashedCanonicalRequest;

        // Third Step
        String accessKeySecret = AK_MAP.get(accessKeyId);
        byte[] secretDate = hmac256(accessKeySecret.getBytes(UTF8), date);
        byte[] secretService = hmac256(secretDate, service);
        byte[] secretSigning = hmac256(secretService, "jg_request");
        String signature = DatatypeConverter.printHexBinary(hmac256(secretSigning, stringToSign)).toLowerCase();

        // Last Step
        return String.format("%s Credential=%s/%s, SignedHeaders=%s, Signature=%s", algorithm, accessKeyId, credentialScope, signedHeaders, signature);
    }

    /**
     * 生成规范化的请求头信息
     *
     * @param sk        加密后的私钥，不需要上链时可以为空
     * @param address   请求的账户地址
     * @param timestamp 请求的时间戳
     * @return 规范化的请求头信息
     */
    private static String generateCanonicalHeaders(String sk, String address, String timestamp) {
        StringBuilder canonicalHeaders = new StringBuilder();
        if (!sk.isEmpty()) {
            canonicalHeaders.append(String.format("x-jg-sk:%s\n", sk));
        }
        if (!address.isEmpty()) {
            canonicalHeaders.append(String.format("x-jg-address:%s\n", address));
        }
        canonicalHeaders.append(String.format("x-jg-timestamp:%s\n", timestamp));

        return canonicalHeaders.toString();
    }

    /**
     * 生成参与签名的请求头keys
     *
     * @param sk      加密后的私钥，不需要上链时可以为空
     * @param address 请求的账户地址
     * @return 参与签名的请求头keys
     */
    private static String generateSignedHeaders(String sk, String address) {
        StringBuilder signedHeaders = new StringBuilder();
        if (!sk.isEmpty()) {
            signedHeaders.append("x-jg-sk;");
        }
        if (!address.isEmpty()) {
            signedHeaders.append("x-jg-address;");
        }
        signedHeaders.append("x-jg-timestamp");
        return signedHeaders.toString();
    }
}
