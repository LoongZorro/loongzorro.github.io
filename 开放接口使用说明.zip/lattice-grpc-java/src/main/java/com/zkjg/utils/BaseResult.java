package com.zkjg.utils;

import io.grpc.StatusRuntimeException;

import java.io.Serializable;

public class BaseResult<T> implements Serializable {
    /**
     * 状态码
     */
    private Integer code;

    /**
     * 信息
     */
    private String message;

    /**
     * 数据
     */
    private T data;

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    private BaseResult() {
    }

    public BaseResult<T> code(Integer code) {
        this.code = code;
        return this;
    }

    public BaseResult<T> message(String message) {
        this.message = message;
        return this;
    }

    public BaseResult<T> data(T data) {
        this.data = data;
        return this;
    }

    public static <T> BaseResult<T> success() {
        return new BaseResult<T>().code(GRPCErrorCodeEnum.OK.getCode());
    }

    public static <T> BaseResult<T> success(T data) {
        return new BaseResult<T>().data(data).code(GRPCErrorCodeEnum.OK.getCode());
    }

    public static <T> BaseResult<T> error(GRPCErrorCodeEnum errorCodeEnum, String errorMessage) {
        return new BaseResult<T>().code(errorCodeEnum.getCode()).message(errorMessage);
    }

    public static <T> BaseResult<T> error(StatusRuntimeException error) {
        return new BaseResult<T>().code(error.getStatus().getCode().value()).message(error.getStatus().getDescription());
    }
}
