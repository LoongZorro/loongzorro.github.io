package com.zkjg.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * <a href="https://www.lzltool.com/SM3">online validation website</a>
 */
public class SM3 extends BCProvider {

    private static final String ALGORITHM = "SM3";

    /**
     * digest message
     *
     * @param input input message
     * @return byte array
     */
    private static byte[] digest(byte[] input) {
        try {
            MessageDigest digest = MessageDigest.getInstance(ALGORITHM);
            return digest.digest(input);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * hash message
     *
     * @param input input message
     * @return hex string
     */
    public static byte[] hash(byte[] input) {
        return digest(input);
    }
}