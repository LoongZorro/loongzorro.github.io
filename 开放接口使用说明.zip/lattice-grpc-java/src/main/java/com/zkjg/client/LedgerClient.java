package com.zkjg.client;

import com.zkjg.generated.ledger.v1.BatchWriteLedgerRequest;
import com.zkjg.generated.ledger.v1.BatchWriteLedgerResponse;
import com.zkjg.generated.ledger.v1.CreateBusinessRequest;
import com.zkjg.generated.ledger.v1.CreateBusinessResponse;
import com.zkjg.generated.ledger.v1.CreateProtocolRequest;
import com.zkjg.generated.ledger.v1.CreateProtocolResponse;
import com.zkjg.generated.ledger.v1.LedgerServiceGrpc;
import com.zkjg.generated.ledger.v1.WriteLedgerData;
import com.zkjg.generated.ledger.v1.WriteLedgerRequest;
import com.zkjg.generated.ledger.v1.WriteLedgerResponse;
import com.zkjg.utils.BaseResult;
import io.grpc.ManagedChannel;
import io.grpc.Metadata;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.MetadataUtils;

import java.util.List;

public class LedgerClient {

    /**
     * 创建协议
     *
     * @param suit    行业，一般为[10, 50]
     * @param message 协议的结构体定义，参考google proto
     * @return BaseResult<CreateProtocolResponse>
     */
    public static BaseResult<CreateProtocolResponse> createProtocol(
            long suit,
            String message
    ) {
        ManagedChannel channel = Client.buildChannel();
        LedgerServiceGrpc.LedgerServiceBlockingStub stub = LedgerServiceGrpc.newBlockingStub(channel);

        CreateProtocolRequest request = CreateProtocolRequest.newBuilder()
                .setChainId(Config.CHAIN_ID)
                .setSuite(suit)
                .setMessage(message)
                .build();

        Metadata metadata = Client.buildMetadataWithMessage(request);
        try {
            stub = stub.withInterceptors(MetadataUtils.newAttachHeadersInterceptor(metadata));
            CreateProtocolResponse response = stub.createProtocol(request);
            return BaseResult.success(response);
        } catch (StatusRuntimeException e) {
            return BaseResult.error(e);
        } finally {
            channel.shutdown();
        }
    }

    /**
     * 创建业务合约地址
     *
     * @return BaseResult<CreateBusinessResponse>
     */
    public static BaseResult<CreateBusinessResponse> createBusiness() {
        ManagedChannel channel = Client.buildChannel();
        LedgerServiceGrpc.LedgerServiceBlockingStub stub = LedgerServiceGrpc.newBlockingStub(channel);

        CreateBusinessRequest request = CreateBusinessRequest.newBuilder()
                .setChainId(Config.CHAIN_ID)
                .build();

        Metadata metadata = Client.buildMetadataWithMessage(request);
        try {
            stub = stub.withInterceptors(MetadataUtils.newAttachHeadersInterceptor(metadata));
            CreateBusinessResponse response = stub.createBusiness(request);
            return BaseResult.success(response);
        } catch (StatusRuntimeException e) {
            return BaseResult.error(e);
        } finally {
            channel.shutdown();
        }
    }

    /**
     * 存证单条数据
     *
     * @param uri             协议号
     * @param protocolVersion 协议号对应的协议版本，版本号从0开始递增，每更新一次+1
     * @param businessAddress 业务合约地址
     * @param jsonData        存证的数据，结构参考协议中的定义
     * @return BaseResult<WriteLedgerResponse>
     */
    public static BaseResult<WriteLedgerResponse> write(
            Long uri,
            Integer protocolVersion,
            String businessAddress,
            String jsonData
    ) {
        ManagedChannel channel = Client.buildChannel();
        LedgerServiceGrpc.LedgerServiceBlockingStub stub = LedgerServiceGrpc.newBlockingStub(channel);

        WriteLedgerRequest request = WriteLedgerRequest.newBuilder()
                .setChainId(Config.CHAIN_ID)
                .setUri(uri)
                .setVersion(protocolVersion)
                .setBusinessAddress(businessAddress)
                .setJsonData(jsonData)
                .build();

        Metadata metadata = Client.buildMetadataWithMessage(request);
        try {
            stub = stub.withInterceptors(MetadataUtils.newAttachHeadersInterceptor(metadata));
            WriteLedgerResponse response = stub.write(request);
            return BaseResult.success(response);
        } catch (StatusRuntimeException e) {
            return BaseResult.error(e);
        } finally {
            channel.shutdown();
        }
    }

    /**
     * 批量存证
     *
     * @param uri             协议号
     * @param businessAddress 业务合约地址
     * @param data            批量数据
     * @return BaseResult<BatchWriteLedgerResponse>
     */
    public static BaseResult<BatchWriteLedgerResponse> batchWrite(
            Long uri,
            String businessAddress,
            List<WriteLedgerData> data
    ) {
        ManagedChannel channel = Client.buildChannel();
        LedgerServiceGrpc.LedgerServiceBlockingStub stub = LedgerServiceGrpc.newBlockingStub(channel);

        BatchWriteLedgerRequest request = BatchWriteLedgerRequest.newBuilder()
                .setChainId(Config.CHAIN_ID)
                .setUri(uri)
                .setBusinessAddress(businessAddress)
                .addAllWriteData(data)
                .setAmount(Config.DEFAULT_AMOUNT)
                .setJoule(Config.DEFAULT_JOULE)
                .build();

        Metadata metadata = Client.buildMetadataWithMessage(request);
        try {
            stub = stub.withInterceptors(MetadataUtils.newAttachHeadersInterceptor(metadata));
            BatchWriteLedgerResponse response = stub.batchWrite(request);
            return BaseResult.success(response);
        } catch (StatusRuntimeException e) {
            return BaseResult.error(e);
        } finally {
            channel.shutdown();
        }
    }
}
