package com.zkjg.client;

import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Message;
import com.google.protobuf.util.JsonFormat;
import com.zkjg.utils.Aes;
import com.zkjg.utils.BaseResult;
import com.zkjg.utils.GRPCErrorCodeEnum;
import com.zkjg.utils.OpenApiAuth;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.Metadata;
import org.bouncycastle.util.encoders.Base64;

public class Client {

    public static ManagedChannel buildChannel() {
        return ManagedChannelBuilder.forAddress(Config.IP, Config.PORT)
                .usePlaintext()
                .build();
    }

    /**
     * 构造请求的元数据
     *
     * @param message gRPC方法的请求消息
     * @return 元数据
     */
    public static Metadata buildMetadataWithMessage(Message message) {
        Metadata metadata = new Metadata();
        String encryptedSK = Aes.CTR.encrypt(Config.PRIVATE_KEY.getBytes(), Config.SECRET);
        Metadata.Key<String> sk = Metadata.Key.of(Header.X_JG_SK, Metadata.ASCII_STRING_MARSHALLER);
        metadata.put(sk, encryptedSK);
        metadata.put(sk, Config.SUPPORT_GM);
        Metadata.Key<String> extension = Metadata.Key.of(Header.X_JG_EXTENSION, Metadata.ASCII_STRING_MARSHALLER);
        metadata.put(extension, Config.ALGORITHM);
        String timestampStr = String.valueOf(System.currentTimeMillis() / 1000);
        Metadata.Key<String> timestamp = Metadata.Key.of(Header.X_JG_TIMESTAMP, Metadata.ASCII_STRING_MARSHALLER);
        metadata.put(timestamp, timestampStr);
        Metadata.Key<String> address = Metadata.Key.of(Header.X_JG_ADDRESS, Metadata.ASCII_STRING_MARSHALLER);
        metadata.put(address, Config.ACCOUNT_ADDRESS);

        String payload = Base64.toBase64String(message.toByteArray());
        String signature;
        try {
            signature = OpenApiAuth.generateSignature(encryptedSK, payload, timestampStr, Config.ACCOUNT_ADDRESS);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Metadata.Key<String> authorization = Metadata.Key.of(Header.Authorization, Metadata.ASCII_STRING_MARSHALLER);
        metadata.put(authorization, signature);

        return metadata;
    }

    public static <T extends Message> void handleResult(BaseResult<T> result) {
        try {
            if (result.getCode() == GRPCErrorCodeEnum.OK.getCode()) {
                System.out.println("调用结果：");
                System.out.println(JsonFormat.printer().print(result.getData()));
            } else {
                System.out.println("调用异常：");
                System.out.println(result.getMessage());
            }
        } catch (Exception e) {
            if (e instanceof InvalidProtocolBufferException) {
                System.out.println("无效的Protocol Buffer");
                System.out.println(e.getMessage());
            } else {
                System.out.println(e.getMessage());
            }
        }
    }
}
