package com.zkjg.client;

public class Header {

    public static final String X_JG_SK = "X-JG-SK";
    public static final String X_JG_EXTENSION = "X-JG-Extension";
    public static final String X_JG_TIMESTAMP = "X-JG-Timestamp";
    public static final String X_JG_ADDRESS = "X-JG-Address";
    public static final String Authorization = "Authorization";
}
