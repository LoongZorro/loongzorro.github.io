package com.zkjg.client;

import com.zkjg.generated.contract.v1.CallContractRequest;
import com.zkjg.generated.contract.v1.CallContractResponse;
import com.zkjg.generated.contract.v1.ContractServiceGrpc;
import com.zkjg.generated.contract.v1.DeployContractRequest;
import com.zkjg.generated.contract.v1.DeployContractResponse;
import com.zkjg.utils.BaseResult;
import io.grpc.ManagedChannel;
import io.grpc.Metadata;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.MetadataUtils;

import java.util.List;

public class ContractClient {

    /**
     * 部署Solidity智能合约
     *
     * @param contractName    合约名称
     * @param description     合约描述
     * @param abi             合约的ABI
     * @param bytecode        合约的Bytecode
     * @param constructorArgs 合约的构造函数的入参（没有则为空数组）
     * @return BaseResult<DeployContractResponse>
     */
    public static BaseResult<DeployContractResponse> deploy(
            String contractName,
            String description,
            String abi,
            String bytecode,
            List<String> constructorArgs
    ) {
        ManagedChannel channel = Client.buildChannel();
        ContractServiceGrpc.ContractServiceBlockingStub stub = ContractServiceGrpc.newBlockingStub(channel);

        DeployContractRequest request = DeployContractRequest.newBuilder()
                .setChainId(Config.CHAIN_ID)
                .setName(contractName)
                .setAbi(abi)
                .setBytecode(bytecode)
                .addAllArguments(constructorArgs)
                .setDescription(description)
                .setAmount(Config.DEFAULT_AMOUNT)
                .setJoule(Config.DEFAULT_JOULE)
                .build();

        Metadata metadata = Client.buildMetadataWithMessage(request);
        try {
            stub = stub.withInterceptors(MetadataUtils.newAttachHeadersInterceptor(metadata));
            DeployContractResponse response = stub.deploy(request);
            return BaseResult.success(response);
        } catch (StatusRuntimeException e) {
            return BaseResult.error(e);
        } finally {
            channel.shutdown();
        }
    }

    /**
     * 调用Solidity智能合约中的方法
     *
     * @param abi             合约的ABI
     * @param contractAddress 合约地址
     * @param method          要调用的合约方法名（在ABI中定义的）
     * @param args            要调用的合约方法对应的入参数（无参传空数组即可）
     * @return BaseResult<CallContractResponse>
     */
    public static BaseResult<CallContractResponse> call(
            String abi,
            String contractAddress,
            String method,
            List<String> args
    ) {
        ManagedChannel channel = Client.buildChannel();
        ContractServiceGrpc.ContractServiceBlockingStub stub = ContractServiceGrpc.newBlockingStub(channel);

        CallContractRequest request = CallContractRequest.newBuilder()
                .setChainId(Config.CHAIN_ID)
                .setAbi(abi)
                .setContractAddress(contractAddress)
                .setMethod(method)
                .addAllArguments(args)
                .setAmount(Config.DEFAULT_AMOUNT)
                .setJoule(Config.DEFAULT_JOULE)
                .build();

        Metadata metadata = Client.buildMetadataWithMessage(request);
        try {
            stub = stub.withInterceptors(MetadataUtils.newAttachHeadersInterceptor(metadata));
            CallContractResponse response = stub.call(request);
            return BaseResult.success(response);
        } catch (StatusRuntimeException e) {
            return BaseResult.error(e);
        } finally {
            channel.shutdown();
        }
    }
}
