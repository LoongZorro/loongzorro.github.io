package com.zkjg.client;

public class Config {
    // 节点管理软件的IP地址
    // 询问服务提供商获取
    public static final String IP = "127.0.0.1";
    // 节点管理软件的gRPC端口
    // 询问服务提供商获取
    public static final int PORT = 8080;
    // 链ID
    // 询问服务提供商获取
    public static final int CHAIN_ID = 1;
    // 上链的账户地址
    // 询问服务提供商获取
    public static final String ACCOUNT_ADDRESS = "zltc_Z1pnS94bP4hQSYLs4aP4UwBP9pH8bEvhi";
    // 账户地址对应的私钥
    // 询问服务提供商获取
    public static final String PRIVATE_KEY = "0x23d5b2a2eb0a9c8b86d62cbc3955cfd1fb26ec576ecc379f402d0f5d2b27a7bb";
    // 一把固定位GM
    public static final String SUPPORT_GM = "GM";
    // 固定为AES
    public static final String ALGORITHM = "AES";
    // AES Secret（不要泄漏）
    // 询问服务提供商获取
    public static final String SECRET = "9jo29cr1";

    public static final String DEFAULT_AMOUNT = "0";
    public static final String DEFAULT_JOULE = "0";
    // OpenAPI调用需要的开发者ID
    public static final String ACCESS_KEY_ID = "2X2WAzHem2nJtvvSaQamjGs";
    // OpenAPI调用需要的开发者Secret（不要泄漏）
    public static final String ACCESS_KEY_SECRET = "NoaC7v2oBRBmPGoAcjkX4J";
}
