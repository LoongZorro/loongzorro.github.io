<h1 align="center">Java gRPC 调用节点管理软件文档</h1>

## 1.调用方式

`gRPC`

根据 `.proto` 生成的 Java 代码在 `com.zkjg` 下，以 ledger.v1 包为例，展示调用接口：

```java
public class Example {
    public static void main(String[] args) {
        ManagedChannel channel = ManagedChannelBuilder.forAddress(IP, PORT)
                .usePlaintext()
                .build();
        LedgerServiceGrpc.LedgerServiceBlockingStub stub = LedgerServiceGrpc.newBlockingStub(channel);
        stub = stub.withInterceptors(MetadataUtils.newAttachHeadersInterceptor(metadata));
        WriteLedgerResponse response = stub.write(WriteLedgerRequest.newBuilder()
                .setChainId(1)
                .setUri(8589934596L)
                .setVersion(0)
                .setBusinessAddress("zltc_Zj3VMGzgZj9ujks1moqwzk4MaeUEHza9y")
                .setJsonData("{\"id\":\"2\",\"name\":\"Captain America\"}")
                .build());
    }
}
```

## 2.自定义请求头

| 请求头               | 描述   | 是否启用 |
|-------------------|------|------|
| `X-Jg-Passphrase` | 身份密码 | ✅    |
| `X-Jg-Address`    | 账户地址 | ✅    |
| `X-Jg-Sk`         | 加密私钥 | ✅    |
| `X-Jg-Timestamp`  | 时间戳  | ✅    |

## 3.接口签名

## 4.示例

`X-Jg-Address` 建议每次传递，如果重置过私钥，就无法通过私钥得到正确的地址。

```java
public class Example {
    public static void main(String[] args) {
        Metadata.Key<String> address = Metadata.Key.of("X-Jg-Address", Metadata.ASCII_STRING_MARSHALLER);
        metadata.put(address, "zltc_Z1pnS94bP4hQSYLs4aP4UwBP9pH8bEvhi");
    }
}
```

### AES加密私钥

```java
public class Example {
    public static void main(String[] args) {
        Metadata metadata = new Metadata();
        Metadata.Key<String> authorization = Metadata.Key.of("Authorization", Metadata.ASCII_STRING_MARSHALLER);
        metadata.put(authorization, "Bearer " + JwtUtils.generateToken());

        String encryptedSK = Aes.CTR.encrypt("0x23d5b2a2eb0a9c8b86d62cbc3955cfd1fb26ec576ecc379f402d0f5d2b27a7bb".getBytes(), "9jo29cr1");
        Metadata.Key<String> sk = Metadata.Key.of("X-JG-SK", Metadata.ASCII_STRING_MARSHALLER);
        metadata.put(sk, encryptedSK);
        metadata.put(sk, "GM");

        Metadata.Key<String> extension = Metadata.Key.of("X-JG-Extension", Metadata.ASCII_STRING_MARSHALLER);
        metadata.put(extension, "AES");
    }
}
```
