<h1 align="center">lattice-grpc-java</h1>

<p align="center">
	<strong>gRPC调用节点管理软件的java demo工程</strong>
</p>
<p align="center">
    <a><img alt="jdk" src="https://img.shields.io/badge/JDK-1.8+-green.svg"></a>
    <a><img alt="gRPC" src="https://img.shields.io/badge/gRPC-1.57.1-red.svg"></a>
    <a href="https://www.jetbrains.com"><img alt="IDEA" src="https://img.shields.io/badge/IntelliJ%20IDEA-support-blue.svg"></a>
    <a><img alt="license" src="https://img.shields.io/badge/License-Apache%202.0-orange.svg"></a>
</p>

## 1.环境参数准备

### 1.查看需要配置哪些参数

```java
package com.zkjg.client;

public class Config {
    // 节点管理软件的IP地址
    // 询问服务提供商获取
    public static final String IP = "127.0.0.1";
    // 节点管理软件的gRPC端口
    // 询问服务提供商获取
    public static final int PORT = 8080;
    // 链ID
    // 询问服务提供商获取
    public static final int CHAIN_ID = 1;
    // 上链的账户地址
    // 询问服务提供商获取
    public static final String ACCOUNT_ADDRESS = "zltc_Z1pnS94bP4hQSYLs4aP4UwBP9pH8bEvhi";
    // 账户地址对应的私钥
    // 询问服务提供商获取
    public static final String PRIVATE_KEY = "0x23d5b2a2eb0a9c8b86d62cbc3955cfd1fb26ec576ecc379f402d0f5d2b27a7bb";
    // 一把固定位GM
    public static final String SUPPORT_GM = "GM";
    // 固定为AES
    public static final String ALGORITHM = "AES";
    // AES Secret（不要泄漏）
    // 询问服务提供商获取
    public static final String SECRET = "9jo29cr1";

    public static final String DEFAULT_AMOUNT = "0";
    public static final String DEFAULT_JOULE = "0";
    // OpenAPI调用需要的开发者ID
    public static final String ACCESS_KEY_ID = "2X2WAzHem2nJtvvSaQamjGs";
    // OpenAPI调用需要的开发者Secret（不要泄漏）
    public static final String ACCESS_KEY_SECRET = "NoaC7v2oBRBmPGoAcjkX4J";
}

```

### 2.创建开发者账号

[查看如何创建开发者](./asset/创建开发者.mp4)

### 3.OpenAPI签名

```
src.main.java.com.zkjg.utils.OpenApiAuth
```

## 2.存证

### 2.1 创建协议

查看单元测试方法：`createProtocol`

[创建Protocol Message文档参考](https://protobuf.dev/overview/)

```
src.test.java.com.zkjg.client.LedgerClientTest
```

### 2.2 创建业务合约

查看单元测试方法：`createBusiness`

```
src.test.java.com.zkjg.client.LedgerClientTest
```

### 2.3 存证

查看单元测试方法：`write`

```
src.test.java.com.zkjg.client.LedgerClientTest
```

### 2.4 批量存证

查看单元测试方法：`batchWrite`

```
src.test.java.com.zkjg.client.LedgerClientTest
```

## 3.Solidity智能合约

### 3.1 部署合约

查看单元测试方法：`deploy`

```
src.test.java.com.zkjg.client.ContractClientTest
```

### 3.2 调用合约

查看单元测试方法：`call`

```
src.test.java.com.zkjg.client.ContractClientTest
```